<?php

return [
    'userImages' => 'uploads/users',  //config('constants.userImages');
    'profileImage' => 'resources/assets/uploads/',
    'appName' => 'Lucky Draw',
];