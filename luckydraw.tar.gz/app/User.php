<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class User extends Model implements AuthenticatableContract,
                                    AuthorizableContract,
                                    CanResetPasswordContract
{
    use Authenticatable, Authorizable, CanResetPassword;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'email', 'password'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token'];
	
	//function to get Admin Users
	public static function checkexisringuser($email) 
	{
   		$result = User::whereIn('status', array(1, 2, 4))->where('email', $email)->get();
		return $result;
    }
	
	//function to get login Users
	public static function validateuser($email, $password)
	{
   		$result = User::where('email', $email)->where('password', $password)->first();
		return $result;
    }

    //function to get  Forgot Users
    public static function check_resettoken($token) 
    {
        $result = User::where('status', 1)->where('reset_token', $token)->first();
        return $result;
    }

    /**
     * Accessor function for user's password
     * @return mixed
     * @author Akhilesh Shukla
     **/
    public function getPassword(){
        return $this->password;
    }
}
