<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Participant extends Model
{
    
	/**
     * The database table used by the model.
     *
     * @var string
     */
	 protected $table = 'participants';

    /**
     * Define participant to draw relationship
     * @author Akhilesh Shukla
     **/
    public function draw(){
        return $this->belongsTo('App\Draws', 'luckydraw_id', 'id');
    }
}
