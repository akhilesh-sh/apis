<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Support\Facades\Log;
use Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Mail;
use Validator;
use Hash;
use Session;
use Redirect;
use View;
use App\Managedraw;
use App\Drawresults;
use App\Draws;
use App\Accounthistory;
use App\Transaction;
use App\Invoices;
use App\Share;
use App\Termcondition;
use App\Faq;
use App\Feedback;
use App\Gamerules;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
	
	
	/**
	 * Function to Manage Users
	 * @author Vikas
	 **/
	public function manageusers()
	{
        //Log::info('This is some useful information.');
		return view('admin.manageusers');
	}
	
	
	
	/**
	 * Function to get users ajax for data table
	 * @author Vikas
	 **/
	public function manageusersajax()
	{
		$AllUsers = array();
		$Users = User::where('user_type',2)->get();
		if(count($Users)>0){
			$i=0;
			foreach($Users as $user){
			    $email = $user->email;
				$name = $user->name;
				$last_name = $user->last_name;
				$username = $user->username;
				$phone = $user->phone;
				$balance = $user->balance;
				//$mode_cash = $user->mode_cash;
				/*$name = $user->firstname.' '.$user->lastname;*/
				$usertype = 'user';
				
				if($user->status==1){
					$userstatus = 'Active';
					$cangestatus = 2;
				}
				elseif($user->status==2){
					$userstatus = 'Inactive';
					$cangestatus = 1;
				}
				elseif($user->status==4){
					$userstatus = 'Pending';
					$cangestatus = 1;
				}
				else{
					$userstatus = 'Deleted';
				}
				
				$created = json_decode(json_encode($user->created_at),true);

				if(isset($created['date'])){
					$created = 	$created['date'];
					$created = current(explode('.',$created));
				}
				else{
					$created = $user->created_at;	
					$created = current(explode('.',$created));
				}
				
				$loginhtml='';

				if($user->status!=3){
					if($user->status == 1){
						$icon = 'close';
						$loginhtml = '<a href="'.Request::root().'/admin/loginasadmin/'.$user->id.'">Login as Admin</a>';
					}
					else
					{
						$icon = 'check';
					}
					
					$html = /*<a href="javascript:void(0);" onClick="open_deleteuserform('.$user->id.',3);"><i class="md md-delete"></i></a>*/' <a href="javascript:void(0);" onClick="changeuserstatus('.$user->id.','.$cangestatus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else
				{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				
				$Arr = array($user->id, $user->email, $user->name, $user->last_name, $user->username, $user->phone, $user->balance, $html);
				$AllUsers['data'] []= $Arr;
				$i++;
			}
		}
		
		if(!empty($AllUsers))
		{
			return json_encode($AllUsers);
		}
		else
		{
			return '{ "data":[] }';
		}
	}
	

	/**
	 * Function to Update User Status
	 * @author Vikas
	 **/
	public function updateusersstatus()
	{
		$data = Request::all();
		$user = User::findOrFail($data['id']);
		$user->status =$data['status'];
		if($data['status'] == 2 || $data['status'] == 3){
			$user->api_token = ''; //Logout user if disabled or deleted.
		}
		$user->update();
		return 1;
	}
	
	
	
	/**
	 * Function Manage Admin profile
	 * @author Vikas
	 **/
	public function manageprofile()
	{
		$Userinfo = User::find(Auth::user()->id);
		return View::make('admin.manageprofile')->with('Userinfo',$Userinfo);
	}
	
	/**
	 * Function Update Admin profile
	 * @author Vikas
	 **/
	public function updateprofile()
	{
		$data = Request::all();
		$User = User::findOrFail(Auth::user()->id);
		$User->name = $data['name'];
		$User->last_name = $data['last_name'];
		$User->paypal_id = $data['paypal_id'];
		//$User->paypal_secret_key = $data['paypal_secret_key'];
		
		if($_FILES["image"]["name"]!=''){
				Validator::extend('img_upload_size', function($attribute, $value, $parameters)
				{
					$file = Request::file($attribute);
					$image_size = $file->getClientSize();
					if( (isset($parameters[0]) && $parameters[0] != 0) && $image_size > $parameters[0]) return false;
					return true;
				});
				
				$rules = array(
					'image' => 'required|mimes:jpeg,bmp,png|img_upload_size:1000000',
					
				);
				
				$messages = array(
					'upload.required' => 'image is required',
					'upload.img_upload_size' => 'image can not be greater then 1MB',
				);
			   
				$validator = Validator::make($data, $rules, $messages);
				
				if ( $validator->fails() ){
					$html = '';
					foreach($validator->messages()->getMessages() as $field_name => $messages) {
						// Go through each message for this field.
						foreach($messages AS $message) {
							$html .= $message.'<br />';
						}
					}
					return $html;
				}
				
				$name       = explode(".", $_FILES["image"]["name"]);
				$imagename  = md5(uniqid(mt_rand(), true)).'.'.end($name);
				$src        = config('constants.profileImage');



                Request::file('image')->move($src, $imagename);
				$User->image = $imagename;
				
				
			}
		
		
		
		
		if(trim($data['pass'])!=''){
			$User->password = Hash::make($data['pass']);
		}
			
		
		$User->update();
		return Redirect::back()->with('message', 'Settings updated successfully!');
	}
	
	
	/**
	 * Function to Check User already Exist
	 * @author Vikas
	 **/
	public function checkexisringuser()
	{
		$data = Request::all();
		$user =  User::checkexisringuser($data['email']);
		if(count($user)>0)
		{
			echo '{ "valid": false }';exit;
		}
		else
		{
			echo '{ "valid": true }';exit;
		}
	}
	
	
	/**
	 * Function to Check User Password
	 * @author Vikas
	 **/
	public function checkexisringuserpassword()
	{
		$data = Request::all();
		$check =  Hash::check($data['password'],Auth::user()->password);
		if($check!=1)
		{
			echo '{ "valid": false }';exit;
		}
		else
		{
			echo '{ "valid": true }';exit;
		}
	}
	
		
	/**
	 * Function to create new user 
	 * @author Vikas
	 **/
	public function createnewusers()
	{
	    $categories = User::get();
		return view('admin.createnewusers')->with('categories',$categories );
	}
	
	
	/**
	 * Function Create new user Page save
	 * @author Vikas
	 **/
	public function postcreatenewusers()
    {
		$data = Request::all();
		$User = new User;
		$User->email = $data['email'];
		$User->password =  Hash::make($data['password']);
		$User->name = $data['name'];
		$User->last_name = $data['last_name'];
		$User->phone = $data['phone'];
		$User->user_type =  2;
		$User->status = 1;
		$User->save();
		return Redirect::to('admin/createnewusers')->with('message', 'New User Created successfully!');
	
	}
	
	
	/**
	 * Function Manage Draws
	 * @author Vikas
	 **/
	public function managedraw()
	{
	    $categories = Managedraw::get();
		return view('admin.managedraw')->with('categories',$categories );
	}
	
	protected function getTime($minutes)
	{
		$hours = (int) ($minutes/60);
		$mins = $minutes%60;
		return ['hours'=>$hours, 'mins'=>$mins];
	}

	
	/**
	 * function to get managedrawajax
	 * @author Vikas
	 **/
	public function managedrawajax()
	{
		$Categories = Managedraw::where('status','!=', 3)->where('type',0)->orderBy('priority')->get();
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				$name 		= $category->price;
				$startdate 	= date('Y-m-d', $category->startdate);
				$enddate 	= date('Y-m-d', $category->enddate);
				$timeframe 	= $category->timeframe;
				$time 		= $this->getTime($category->timeframe);
				$the_time   = $time['hours'].':'.$time['mins'];
				$profit 	= $category->profit;
				$priority 	= '<input class="priority-update" type="number" min="1" value="'.$category->priority.'" data-category-id="'.$category->id.'"/>';
				$type 	    = $category->type;
				if($type != 0){
					$the_time = '--';
				}
				//$type_data = array();
				/*if($time == 0){
					$type_data = 'Draw';
				}
				else{
					$type_data = 'Toss';
				}*/
				if($category->type ==0){
					$type_data = 'Draw';
					
				}
				elseif($category->type ==1){
					$type_data = 'Toss';
					
				}
				else{
					$type_data = 'Lucky Dice';
				}
				
				$now 		= time();
				//$winner_id = $category->winner_id;
				
				if($category->status==1){
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				elseif($category->status==2){
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}
				if($category->startdate > $now || $category->enddate < $now){
					$categorystatus = 'Inactive';
				}
				
				$created = json_decode(json_encode($category->created_at),true);				

				if(isset($created['date'])){
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				if($category->status!=3){
					if($category->status == 1){
						$icon = 'close';
					}
					else{
						$icon = 'check';
					}

					$html = '<a href="javascript:void(0);" onClick="open_editcatform('.$category->id.');"><i class="md md-edit"></i></a> <a href="javascript:void(0);" onClick="open_deletecatform('.$category->id.',3);"><i class="md md-delete"></i></a> <a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				
				$Arr = array($category->id, $name, $priority, $startdate, $enddate, $the_time, $profit, $type_data, $categorystatus, $created, $html);
				$AllCategories['data'] []= $Arr;
			}
		}

		if(!empty($AllCategories)){
			return json_encode($AllCategories);
		}
		else{
			return '{ "data":[] }';
		}
	}
	

	/**
	 * function to get managedrawajax
	 * @author Vikas
	 **/
	public function managedrawajax2()
	{
		$Categories = Managedraw::where('status','!=', 3)->where('type',1)->orderBy('priority')->get();
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				$name 		= $category->price;
				$startdate 	= date('Y-m-d', $category->startdate);
				$enddate 	= date('Y-m-d', $category->enddate);
				$timeframe 	= $category->timeframe;
				$time 		= $this->getTime($category->timeframe);
				$the_time   = $time['hours'].':'.$time['mins'];
				$profit 	= $category->profit;
				$priority 	= '<input class="priority-update" type="number" min="1" value="'.$category->priority.'" data-category-id="'.$category->id.'"/>';
				$type 	    = $category->type;
				if($type != 0){
					$the_time = '--';
				}
				//$type_data = array();
				/*if($time == 0){
					$type_data = 'Draw';
				}
				else{
					$type_data = 'Toss';
				}*/
				if($category->type ==0){
					$type_data = 'Draw';
					
				}
				elseif($category->type ==1){
					$type_data = 'Toss';
					
				}
				else{
					$type_data = 'Lucky Dice';
				}
				
				$now 		= time();
				//$winner_id = $category->winner_id;
				
				if($category->status==1){
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				elseif($category->status==2){
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}
				if($category->startdate > $now || $category->enddate < $now){
					$categorystatus = 'Inactive';
				}
				
				$created = json_decode(json_encode($category->created_at),true);				

				if(isset($created['date'])){
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				if($category->status!=3){
					if($category->status == 1){
						$icon = 'close';
					}
					else{
						$icon = 'check';
					}

					$html = '<a href="javascript:void(0);" onClick="open_editcatform('.$category->id.');"><i class="md md-edit"></i></a> <a href="javascript:void(0);" onClick="open_deletecatform('.$category->id.',3);"><i class="md md-delete"></i></a> <a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				
				$Arr = array($category->id, $name, $priority, $startdate, $enddate, $the_time, $profit, $type_data, $categorystatus, $created, $html);
				$AllCategories['data'] []= $Arr;
			}
		}

		if(!empty($AllCategories)){
			return json_encode($AllCategories);
		}
		else{
			return '{ "data":[] }';
		}
	}
	

	/**
	 * function to get managedrawajax
	 * @author Vikas
	 **/
	public function managedrawajax3()
	{
		$Categories = Managedraw::where('status','!=', 3)->where('type',2)->orderBy('priority')->get();
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				$name 		= $category->price;
				$startdate 	= date('Y-m-d', $category->startdate);
				$enddate 	= date('Y-m-d', $category->enddate);
				$timeframe 	= $category->timeframe;
				$time 		= $this->getTime($category->timeframe);
				$the_time   = $time['hours'].':'.$time['mins'];
				$profit 	= $category->profit;
				$priority 	= '<input class="priority-update" type="number" min="1" value="'.$category->priority.'" data-category-id="'.$category->id.'"/>';
				$type 	    = $category->type;
				if($type != 0){
					$the_time = '--';
				}
				//$type_data = array();
				/*if($time == 0){
					$type_data = 'Draw';
				}
				else{
					$type_data = 'Toss';
				}*/
				if($category->type ==0){
					$type_data = 'Draw';
					
				}
				elseif($category->type ==1){
					$type_data = 'Toss';
					
				}
				else{
					$type_data = 'Lucky Dice';
				}
				
				$now 		= time();
				//$winner_id = $category->winner_id;
				
				if($category->status==1){
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				elseif($category->status==2){
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}
				if($category->startdate > $now || $category->enddate < $now){
					$categorystatus = 'Inactive';
				}
				
				$created = json_decode(json_encode($category->created_at),true);				

				if(isset($created['date'])){
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				if($category->status!=3){
					if($category->status == 1){
						$icon = 'close';
					}
					else{
						$icon = 'check';
					}

					$html = '<a href="javascript:void(0);" onClick="open_editcatform('.$category->id.');"><i class="md md-edit"></i></a> <a href="javascript:void(0);" onClick="open_deletecatform('.$category->id.',3);"><i class="md md-delete"></i></a> <a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				
				$Arr = array($category->id, $name, $priority, $startdate, $enddate, $the_time, $profit, $type_data, $categorystatus, $created, $html);
				$AllCategories['data'] []= $Arr;
			}
		}

		if(!empty($AllCategories)){
			return json_encode($AllCategories);
		}
		else{
			return '{ "data":[] }';
		}
	}
	
	
	
	/**
	 * function to get Draw Details by ajax
	 * @author Vikas
	 **/
	public function adddrawajax()
	{
		$data = Request::all();
		$category = new Managedraw;
		$category->price = $data['price'];
		$category->startdate = strtotime($data['startdate']);
		$category->enddate = strtotime($data['enddate']);
		$category->timeframe = $data['hours']*60 + $data['minutes'];
		$category->profit = $data['profit'];
		$category->priority = $data['priority'];
		$category->type = $data['type'];

		$category->status = 1;
		$category->save();
		$now = time();


		if(($data['type'] == 1 || $data['type'] == 2)){
			$newDraw                = new Draws;
            $newDraw->drawid        = $category->id;
            $newDraw->amount        = 0;
            $newDraw->participants  = 0;
            $newDraw->type          = $data['type'];
            $newDraw->status        = 1;
            $newDraw->winner_id     = 0;
            $newDraw->profit_perc   = $category->profit;
            $newDraw->priority   	= $category->priority;
            $newDraw->save();
		}

		return 1;
	}
	//startdate = date('d-m-Y', $data['startdate']);
	//enddate = date('d-m-Y', $data['enddate']);
	 
	/**
	 * function to Update Draw Status
	 * @author Vikas
	 **/
	public function updatedrawstatus()
	{
		$data = Request::all();
		$category = Managedraw::findOrFail($data['id']);
		$category->status =$data['status'];
		$category->update();
		return 1;
	}
	
	
	public function updatepriorityajax(){
		$data = Request::all();
		$category = Managedraw::find($data['catid']);
		$category->priority = $data['priority'];
		$category->save();

		Draws::where('status', 1)->where('drawid', $data['catid'])->update(['priority' => $data['priority']]);
		return 1;
	}
	/**
	 * function update Draw  Details by ajax
	 * @author Vikas
	 **/
	public function updatedrawajax()
	{
		$data = Request::all();
		$category = Managedraw::findOrFail($data['catid']);
		$category->price = $data['price'];
		$category->startdate = strtotime($data['startdate']);
		$category->enddate = strtotime($data['enddate']);
		$category->timeframe = ($data['hours']*60) + $data['minutes'];
		$category->profit = $data['profit'];
		$category->priority = $data['priority'];
		//$category->type = $data['type'];
		$category->status = 1;
		$category->update();

		Draws::where('drawid', $category->id)->where('status', 1)->update(['priority'=> $category->priority]);
		return 1;
	}
	
	 
	/**
	 * function to Edit Draw ajax
	 * @author Vikas
	 **/
	public function editdrawajax()
	{
		$data = Request::all();
		$Category = Managedraw::find($data['catid']);
		$time = $this->getTime($Category->timeframe);
		$Category->startdate= date('Y-m-d', $Category->startdate);
		$Category->enddate=date('Y-m-d', $Category->enddate);
		$Category->hours = $time['hours'];
		$Category->mins = $time['mins'];
		return response()->json($Category);
	}
	
   
	/**
	 * Function Manage Draw Results
	 * @author Vikas
	 **/
	public function managedrawresults()
	{
		return view('admin.managedrawresults');
	}

   
	/**
	 * Function to get manage results draw ajax
	 * @author Vikas
	 **/
	public function managedrawresultsajax()
	{
		$Categories = Draws::where('status', 2)->get();
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				//$image = '<a class=""  href="'.Request::root().'/uploads/'.$category->image.'" ><img height="100" width="100" class="gridimg" src="'.Request::root().'/uploads/'.$category->image.'"></a>';
				$drawid = $category->drawid;
				$amount = $category->amount;
				$participants = $category->participants;
				$winner_id = $category->winner_id;
				
				if($participants == 0)
				{
					$participants = 'No Participants';
				}

				if($winner_id == 0)
				{
					$winner_id = 'N/A';
				}
				
				if($category->status==1)
				{
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				else if($category->status==2)
				{
					$categorystatus = 'Complete';
					$cangestastus = 1;
				}
				else
				{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}
				
				$created = json_decode(json_encode($category->created_at),true);				
				if(isset($created['date']))
				{
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else
				{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				if($category->status!=3)
				{
					if($category->status == 1)
					{
						$icon = 'close';
					}
					else
					{
						$icon = 'check';
					}
					$html = '<a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else
				{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				$Arr = array($category->id, $drawid, $amount,  $participants, $winner_id, $categorystatus, $created, $html);
				$AllCategories['data'] []= $Arr;
			}
		}
		if(!empty($AllCategories))
		{
			return json_encode($AllCategories);
		}
		else
		{
			return '{ "data":[] }';
		}
	}
	

	/**
	 * Function to Update Draw Results Status
	 * @author Vikas
	 **/
	public function updateresultsstatus()
	{
		$data = Request::all();
		$category = Draws::findOrFail($data['id']);
		$category->status =$data['status'];
		$category->update();
		return 1;
	}

    
    /**
	 * Function Manage Draw 
	 * @author Vikas
	 **/
	public function draws()
	{
		return view('admin.draws');
	}

    
    /**
	 * Function to get drawsajax
	 * @author Vikas
	 **/
	public function drawsajax()
	{
		$Categories = Draws::where('status', 1)->with('managedraw')->get();
		//dd($Categories);
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				//$image = '<a class=""  href="'.Request::root().'/uploads/'.$category->image.'" ><img height="100" width="100" class="gridimg" src="'.Request::root().'/uploads/'.$category->image.'"></a>';
				$drawid       = $category->drawid;
				$price        = $category->price;
				$amount       = $category->amount;
				$profit       = $category->amount * ($category->profit_perc/100);
				$winning_amt  = $category->amount - $profit;
				$participants = $category->participants;
				$type 	      = $category->managedraw->type;
				//$type_data  = array();
				/*if($type == 0){
					$type_data = 'Draw';
				}
				else{
					$type_data = 'Toss';
				}*/

				if($category->type == 0){
					$type_data = 'Draw';
					
				}
				elseif($category->type == 1){
					$type_data = 'Toss';
					
				}
				else{
					$type_data = 'Lucky Dice';
				}
				//$winner_id = $category->winner_id;

				/*if($category->status==1)
				{
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				else if($category->status==2)
				{
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else
				{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}*/
				
				$created = json_decode(json_encode($category->created_at),true);				
				if(isset($created['date']))
				{
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else
				{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				/*if($category->status!=3)
				{
					if($category->status == 1)
					{
						$icon = 'close';
					}
					else
					{
						$icon = 'check';
					}
					$html = '<a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else
				{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}*/
				$Arr = array($category->id, $drawid, $type_data, $amount, $profit, $winning_amt, $participants, /*$winner_id, $categorystatus,*/ $created/*, $html*/);
				$AllCategories['data'] []= $Arr;
			}
		}
		if(!empty($AllCategories))
		{
			return json_encode($AllCategories);
		}
		else
		{
			return '{ "data":[] }';
		}
	}
    

    /**
	 * Function to Update Draws Status
	 * @author Vikas
	 **/
	public function updateddrawsstatus()
	{
		$data = Request::all();
		$category = Draws::findOrFail($data['id']);
		$category->status =$data['status'];
		$category->update();
		return 1;
	}

  
	/**
	 * Function Manage Account History
	 * @author Vikas
	 **/
	public function accounthistory()
	{
		return view('admin.accounthistory');
	}

    
    /**
	 * function to get Account History
	 * @author Vikas
	 **/
	public function accounthistoryajax()
	{
		$Categories = Accounthistory::get();
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				//$image = '<a class=""  href="'.Request::root().'/uploads/'.$category->image.'" ><img height="100" width="100" class="gridimg" src="'.Request::root().'/uploads/'.$category->image.'"></a>';
				$userid = $category->userid;
				//$type = $category->type;
				
		
				
				if($category->status==1)
				{
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				else if($category->status==2)
				{
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else
				{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}
				
				$created = json_decode(json_encode($category->created_at),true);				
				if(isset($created['date']))
				{
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else
				{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				if($category->status!=3)
				{
					if($category->status == 1)
					{
						$icon = 'close';
					}
					else
					{
						$icon = 'check';
					}
					$html = '<a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else
				{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				$Arr = array($category->id, $userid,  $categorystatus, $created, $html);
				$AllCategories['data'] []= $Arr;
			}
		}
		if(!empty($AllCategories))
		{
			return json_encode($AllCategories);
		}
		else
		{
			return '{ "data":[] }';
		}
	}
    

    /**
	 * function to Update Account Status
	 * @author Vikas
	 **/
	public function updatedaccountstatus()
	{
		$data = Request::all();
		$category = Accounthistory::findOrFail($data['id']);
		$category->status =$data['status'];
		$category->update();
		return 1;
	}


	/**
	 * Function Manage Transation Section
	 * @author Vikas
	 **/
	public function managetransaction()
	{
		return view('admin.managetransaction');
	}


    /**
	 * Function to get Transaction Ajax
	 * @author Vikas
	 **/
	public function managetransactionajax()
	{
		$Categories = Transaction::with('user')->get();
		// dd($Categories);
		$AllCategories = array();
		if(count($Categories)>0){
			foreach($Categories as $category){
				
				$name 		= $category->user->name;
				$amount 	= '$'. number_format(floatval($category->amount), 2, '.', '');
				$type 		= $category->type;
				$payment_id = $category->payment_id;
				$amtValue	= '$'. number_format(floatval($category->amt_value), 2, '.', '');
				$profee		= '$'. number_format($amount - $amtValue, 2, '.', ''); //$category->processing_fee;
				$payoutId	= $category->payout_item_id;

		        
		        if($type == 1){
					$type = 'Deposit';
				}
				elseif($type == 2){
					$type = 'Withdraw';
				}
				
				/*if($category->status==1){
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				elseif($category->status==2){
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}*/
				
				$created = json_decode(json_encode($category->created_at),true);

				if(isset($created['date'])){
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				/*if($category->status!=3){
					if($category->status == 1){
						$icon = 'close';
					}
					else{
						$icon = 'check';
					}
					$html = '<a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}*/

				$Arr = array($category->id, $name, $amount, $amtValue, $type, $payment_id, $payoutId, $profee, $category->status, $created);
				$AllCategories['data'] []= $Arr;
			}
		}
		if(!empty($AllCategories))
		{
			return json_encode($AllCategories);
		}
		else
		{
			return '{ "data":[] }';
		}
	}


	/**
	 * Function to Update Transaction Status
	 * @author Vikas
	 **/
	public function updatedtransactionstatus()
	{
		$data = Request::all();
		$category = Transaction::findOrFail($data['id']);
		$category->status =$data['status'];
		$category->update();
		return 1;
	}


    /**
	 * Function Manage Invoices Section
	 * @author Vikas
	 **/
	public function manageinvoices()
	{
		return view('admin.manageinvoices');
	}

    
    /**
	 * Function to get Invoices Ajax
	 * @author Vikas
	 **/
	public function manageinvoicesajax()
	{
		$Categories = Invoices::get();
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				//$image = '<a class=""  href="'.Request::root().'/uploads/'.$category->image.'" ><img height="100" width="100" class="gridimg" src="'.Request::root().'/uploads/'.$category->image.'"></a>';
				$invoicesid = $category->invoicesid;
				$transactionid 	 = $category->transactionid;
				$userid = $category->userid;
				$amount = $category->amount;
		
				
				if($category->status==1)
				{
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				else if($category->status==2)
				{
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else
				{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}
				
				$created = json_decode(json_encode($category->created_at),true);				
				if(isset($created['date']))
				{
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else
				{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				if($category->status!=3)
				{
					if($category->status == 1)
					{
						$icon = 'close';
					}
					else
					{
						$icon = 'check';
					}
					$html = '<a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else
				{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				$Arr = array($category->id, $invoicesid, $transactionid,  $userid, $amount, $categorystatus, $created, $html);
				$AllCategories['data'] []= $Arr;
			}
		}
		if(!empty($AllCategories))
		{
			return json_encode($AllCategories);
		}
		else
		{
			return '{ "data":[] }';
		}
	}


    /**
	 * Function to Update Invoices Status
	 * @author Vikas
	 **/
	public function updatedinvoicesstatus()
	{
		$data = Request::all();
		$category = Invoices::findOrFail($data['id']);
		$category->status =$data['status'];
		$category->update();
		return 1;
	}


	/**
	 * Function Manage Shared Section
	 * @author Vikas
	 **/
	public function manageshare()
	{
		$Userinfo = Share::first();
		return View::make('admin.manageshare')->with('Userinfo',$Userinfo);
	}

	
	/**
	 * Function share Page update and save
	 * @author Vikas
	 **/
	public function updateshare()
    {
		$data = Request::all();
		$share = Share::find(1);
		if(count($share)>0)
		{

			if($_FILES["image"]["name"]!='')
			{
				Validator::extend('img_upload_size', function($attribute, $value, $parameters)
				{
					$file = Request::file($attribute);
					$image_size = $file->getClientSize();
					if( (isset($parameters[0]) && $parameters[0] != 0) && $image_size > $parameters[0]) return false;
					return true;
				});
				
				$rules = array(
					'image' => 'required|mimes:jpeg,bmp,png|img_upload_size:1000000',
					
				);
				
				$messages = array(
					'upload.required' => 'image is required',
					'upload.img_upload_size' => 'image can not be greater then 1MB',
				);
			   
				$validator = Validator::make($data, $rules, $messages);
				
				if ( $validator->fails() )
				{
					$html = '';
					foreach($validator->messages()->getMessages() as $field_name => $messages) {
						// Go through each message for this field.
						foreach($messages AS $message) {
							$html .= $message.'<br />';
						}
					}
					return $html;
				}
				
				$name = explode(".", $_FILES["image"]["name"]);
				$imagename=md5(uniqid(mt_rand(), true)).'.'.end($name);
				$src        = config('constants.profileImage');         
				
				
				
				//$data['url'] = Request::root().'/resources/assets/uploads'.$imagename;
				
				// move_uploaded_file( $_FILES["image"]["tmp_name"], $src);
				Request::file('image')->move($src, $imagename);
				$share->image = $imagename;
				
				
			}

		    //$share = Share::find(1);
			$share->title = $data['title'];
			$share->description = $data['description'];
			$share->update();
		}
		else
		{
			$share = new Share;


			if($_FILES["image"]["name"]!='')
			{
				Validator::extend('img_upload_size', function($attribute, $value, $parameters)
				{
					$file = Request::file($attribute);
					$image_size = $file->getClientSize();
					if( (isset($parameters[0]) && $parameters[0] != 0) && $image_size > $parameters[0]) return false;
					return true;
				});
				
				$rules = array(
					'image' => 'required|mimes:jpeg,bmp,png|img_upload_size:1000000',
					
				);
				
				$messages = array(
					'upload.required' => 'image is required',
					'upload.img_upload_size' => 'image can not be greater then 1MB',
				);
			   
				$validator = Validator::make($data, $rules, $messages);
				
				if ( $validator->fails() )
				{
					$html = '';
					foreach($validator->messages()->getMessages() as $field_name => $messages) {
						// Go through each message for this field.
						foreach($messages AS $message) {
							$html .= $message.'<br />';
						}
					}
					return $html;
				}
				
				$name = explode(".", $_FILES["image"]["name"]);
				$imagename=md5(uniqid(mt_rand(), true)).'.'.end($name);
				$src        = config('constants.profileImage');         
				
				
				
				//$data['url'] = Request::root().'/resources/assets/uploads'.$imagename;
				
				// move_uploaded_file( $_FILES["image"]["tmp_name"], $src);
				Request::file('image')->move($src, $imagename);
				$share->image = $imagename;
				
				
			}
			$share->title = $data['title'];
			$share->description = $data['description'];
			$share->save();
		}
		return Redirect::to('admin/manageshare')->with('message', 'Data updated successfully!');
	
	}


	/**
	* Manage terms and conditions
	* @author Nancy Sharma
	*/
	public function termsCondition(){
		$terms_data = Termcondition::get();
		
		if(count($terms_data) == 1){
			$terms_data_array	= $terms_data->toarray();
			$title 				= array_column($terms_data_array, 'title');
			$title1 			= implode(" ",$title );
			$description 		= array_column($terms_data_array, 'description');
			$description1 		= implode(" ",$description );
			$terms 				= array(
				'title'			=> $title1,
				'description'	=> $description1
			);
			return view('admin.termscondition')->with($terms);
		}
		else{
			$title 			= '';
			$description 	= '';
			$terms 			= array(
				'title'			=> $title,
				'description'	=> $description
			);
			return view('admin.termscondition')->with($terms);
		}

	}


	/**
	* Store and update terms & conditions
	* @author Nancy Sharma
	*/
	public function terms(Request $request){

		$data               	= Request::all();
		$terms_data 			= Termcondition::get();

		if(count($terms_data) == 1){

			$newdata 				 =  Request::all();
			$terms_1 		    	 = $terms_data->toarray();
			$id 					 = array_column($terms_1, 'id');
			$id1 					 = implode(" ",$id );
			$termsdata1 			 =  Termcondition::find($id1);
    		$termsdata1->title 		 = $newdata['title'];
    		$termsdata1->description = $newdata['description'];
    		$termsdata1->save();
    		return redirect()->route('conditions')->with('message', 'Term condition updated successfully!');
		}

		else{

			$terms_data              = new Termcondition;
			$terms_data->title       = $data['title'];
			$terms_data->description = $data['description'];

			$terms_data->save();
			return redirect()->route('conditions')->with('message', 'New Term condition Created successfully!');
		}		
	}

	/**
	 * Function Manage Setings Section
	 * @author Vikas
	 **/
	public function settings()
	{
		$Userinfo = User::find(1);
		return view('admin.settings')->with('Userinfo',$Userinfo);
	}

	
	/**
	 * Function Settings Page update and save
	 * @author Vikas
	 **/
	public function updatesettings()
    {
		$data 		= Request::all();
		$settings 	= User::find(1);

		if($settings) {}
		else{
			$settings = new User;
		}

		$settings->paypal_secret_key 	= $data['paypal_secret_key'];
		$settings->paypal_env 			= $data['paypal_env'];
		$settings->save();

		return redirect('admin/settings')->with('message', 'Settings updated successfully!');
	
	}

    /**
     * Display Contact Form details
     * @author Vikas Sharma
     **/
	public function contactUsSubmissions(){
        return view('admin.contactUsSubmissions');
    }
    
    /**
     * Display Contact Form details Ajax
     * @author Vikas Sharma
     **/
    public function contactUsSubmissionsAjax(){
        $data       = Feedback::get();
        $AllDemo    = array();
        $i          = 1;

        foreach($data as $booking){
        	$created = $booking->created_at->format('Y-m-d H:i:s');
        	
            $Arr = array($i++, $booking->name, $booking->email, $booking->message, /*$booking->requestermsg,*/ $created, '<a class="details" href="'.url('/admin/contactUsSubmissions/details/'.$booking->id).'"> View </a>');
            $AllDemo['data'][] = $Arr;
        }

        return response()->json($AllDemo);
    }

    public function submissionDetails($id){
        $submission = Feedback::find($id);
        return view('admin.submissionDetail')->with('submission', $submission);
    }

	/**
     * Display push notification page
     * @author Akhilesh Shukla
     **/
    public function pushnotification(){
        return view('admin.pushnotification');
    }

    /**
     * Send a push notification and store it to database
     * @author Akhilesh Shukla
     */
    public function sendpushnotification(\Illuminate\Http\Request $request){
        $data  = $request->all();
        $users = \DB::table('gcm_user')->get();

        $registrationIds = array();
        $AppleIds = array();

        if(count($users)>0){
            foreach($users as $user){
                if($user->gcm_regid!='' && strtolower($user->device_type)!='ios'){
                    $registrationIds[] = trim($user->gcm_regid);
                }
                if($user->gcm_regid!='' && strtolower($user->device_type)=='ios'){
                    $AppleIds[] = trim($user->gcm_regid);
                }
            }
        }

        if (!empty($registrationIds) || !empty($AppleIds)){
            if (!empty($registrationIds)){
                $notification['email'] 		 = 'all';
                $notification['title']       = $data['title'];
                $notification['message']     = $data['message'];
                $notification['created_at']  = date('Y-m-d H:i:s');
                $notification['updated_at']  = date('Y-m-d H:i:s');

                \DB::table('notifications')->insert($notification);

                // prep the bundle
                $largeicon = url('/resources/assets/images/logo.png');
                $smallIcon = url('/resources/assets/images/logo.png');

                $msg = array(
                    'title'         => $data['title'],
                    'subtitle'      => 'New Notification',
                    'tickerText'    => 'Lucky Draw Notification',
                    'vibrate'       => 1,
                    'sound'         => 1,
                    'largeIcon'     => $largeicon,
                    'smallIcon'     => $smallIcon,
                    'message'       => $data['message'],
                );
                
                $fields = array(
                    'registration_ids'  => $registrationIds,
                    'data'          => $msg
                );

                $headers = array(
                    'Authorization: key=AIzaSyAi-WlPWQvpnun4m5i5DYUQ80rU8q7fC2g',//Server Key
                    'Content-Type: application/json'
                );

                $ch = curl_init();
                curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
                curl_setopt( $ch,CURLOPT_POST, true );
                curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
                curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
                curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
                curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
                $result = curl_exec($ch );
                curl_close( $ch );
            }
            if(!empty($AppleIds)){
                foreach($AppleIds as $AppleId){
                    // our token
                    $deviceToken = $AppleId;

                    // The password for the .pem file
                    $passphrase = 'Envision@123';

                    // The push message
                    $message = $data['message'];

                    $ctx = stream_context_create();
                    //We specify the path to .pem certificate we created
                    stream_context_set_option($ctx, 'ssl', 'local_cert', app_path('Http/Controllers/ApplePushCer/Certificates_GymApp_Dev.pem'));
                    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

                    // Open connection with APNS
                    $fp = stream_socket_client(
                        'ssl://gateway.sandbox.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

                    if (!$fp) {
                        $request->session()->flash('message', "Error connection: $err $errstr");
                        return redirect('/admin/pushnotification');
                    }


                    // We create the payload
                    $body['aps'] = array(
                        'alert' => $message,
                        'sound' => 'bingbong.aiff',
                        'badge' => 1
                    );

                    // Json Format
                    $payload = json_encode($body);

                    // We build the binary message
                    $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

                    // We sent
                    $result = fwrite($fp, $msg, strlen($msg));

                    if (!$result) {
                        $request->session()->flash('message', 'Push Notification Not Sent');
                        return redirect('/admin/pushnotification');
                    }
                    // close the connection
                    fclose($fp);
                }
            }
            $request->session()->flash('message', 'Push Notification Sent Successfully !');
        }
        else{
            $request->session()->flash('message', 'No Device ID Found');
        }

        return redirect('/admin/pushnotification');
    }

    /**
     * Activate the user account based on activation token
     * @param  string $token
     * @author Akhilesh Shukla
     **/
    public function activationtoken($token)
    {
    	$user 	= User::where('activation_token', $token)->first();

    	if($user && is_object($user)){
    		$user->status = 1;
    		$user->update();
    		return view('activation')->with('data', 'User activated successfully! Please login on your app to continue..');
    	}

		return view('activation')->with('data', 'Activation link invalid');
    }


   	 //function to show Faq Content
	  public function faq(){
		$categories = Faq::first();
		return View::make('admin.faq')->with('categories',$categories );
	}
	
	/**
	 * function to get managedrawajax
	 * @author Vikas
	 **/
	public function faqajax()
	{
		$Categories = Faq::get();
		$AllCategories = array();
		if(count($Categories)>0)
		{
			foreach($Categories as $category)
			{
				
				$title 		 = substr($category->title,0,60);
				$description = substr($category->description,0,110);
				
				
				if($category->status==1){
					$categorystatus = 'Active';
					$cangestastus = 2;
				}
				elseif($category->status==2){
					$categorystatus = 'Inactive';
					$cangestastus = 1;
				}
				else{
					$categorystatus = 'Deleted';
					$cangestastus = 3;
				}
				/*if($category->startdate > $now || $category->enddate < $now){
					$categorystatus = 'Inactive';
				}*/
				
				$created = json_decode(json_encode($category->created_at),true);				

				if(isset($created['date'])){
					$created = $created['date'];
					$created = current(explode('.',$created));
				}
				else{
					$created = $category->created_at;	
					$created = current(explode('.',$created));
				}
				
				if($category->status!=3){
					if($category->status == 1){
						$icon = 'close';
					}
					else{
						$icon = 'check';
					}

					$html = '<a href="javascript:void(0);" onClick="open_editcatform('.$category->id.');"><i class="md md-edit"></i></a> <a href="javascript:void(0);" onClick="open_deletecatform('.$category->id.',3);"><i class="md md-delete"></i></a> <a href="javascript:void(0);" onClick="changecatstatus('.$category->id.','.$cangestastus.');"><i class="md md-'.$icon.'"></i></a>';
				}
				else{
					$html =	'<a href="javascript:void(0);" style="color:red;">Deleted</a>';
				}
				
				$Arr = array($category->id, $title, $description .' ...', $categorystatus, $created, $html);
				$AllCategories['data'] []= $Arr;
			}
		}

		if(!empty($AllCategories)){
			return json_encode($AllCategories);
		}
		else{
			return '{ "data":[] }';
		}
	}

	/**
	 * function to Add FAQ Details by ajax
	 * @author Vikas
	 **/
	public function addfaqajax()
	{
		$data = Request::all();
		$category = new Faq;
		$category->title = $data['title'];
		$category->description = $data['description'];
		$category->status = 1;
		$category->save();
		return 1;
	}

	/**
	 * function to Update Faq Status
	 * @author Vikas
	 **/
	public function updatedfaqstatus()
	{
		$data = Request::all();
		$category = Faq::findOrFail($data['id']);
		$category->status =$data['status'];
		$category->update();
		return 1;
	}

	/**
	 * function update Faq  Details by ajax
	 * @author Vikas
	 **/
	public function updatedfaqajax()
	{
		$data = Request::all();
		$category = Faq::findOrFail($data['catid']);
		$category->title = $data['title'];
		$category->description = $data['description'];
		$category->status = 1;
		$category->update();
		return 1;
	}

	/**
	 * function to Edit Faq ajax
	 * @author Vikas
	 **/
	public function editfaqajax()
	{
		$data = Request::all();
		$Category = Faq::find($data['catid']);
		$Category->title = strip_tags($Category->title);
		$Category->description = strip_tags($Category->description);
		return response()->json($Category);
	}

    /**
	 * function to Show Game rules section
	 * @author Vikas
	 **/
	public function gamerules()
	{
		$Userinfo = Gamerules::find(1);
		return view('admin.gamerules')->with('Userinfo',$Userinfo);
	}

	/**
	 * Function Game Rules Page update and save
	 * @author Vikas
	 **/
	public function updategamerules()
    {
		$data = Request::all();
		$Userinfo = Gamerules::find(1);
		if(count($Userinfo)>0)
		{
		    $Userinfo = Gamerules::find(1);
			$Userinfo->title = $data['title'];
			$Userinfo->description = $data['description'];
			$Userinfo->update();
		}
		else
		{
			$Userinfo = new Gamerules;
			$Userinfo->title = $data['title'];
			$Userinfo->description = $data['description'];
			$Userinfo->save();
		}
		return Redirect::to('admin/gamerules')->with('message', 'Data updated successfully!');
	
	}
	
}
