<?php

namespace App\Http\Controllers;

use App\User;
use App\Draws;
use App\Managedraw;
use App\Share;
use App\Faq;
use App\Participant;
use App\Feedback;
use App\Gamerules;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use Mail;
use Validator;
use Hash;
use Session;
use Redirect;
use Post;
use Carbon\Carbon;



class ApiController extends Controller {

	/**
	 * Creates a new user in DB
	 * @author Vikas
	 **/
	public function registerUser(Request $request) {

		$data = $request->all();

		$rules = array(
			'firstname' => 'required',
			'email'     => 'required|email|unique:users'
        );

		$messages = array(
			'required'  => 'This field is required',
			'email'     => 'Please enter a valid email address',
			'unique'    => 'This field must be unique',
		);

		$validator = Validator::make($data, $rules, $messages);
				
		if ($validator->fails()){
			$html = array();
			foreach($validator->messages()->getMessages() as $field_name => $messages) {
				// Go through each message for this field.
				foreach($messages AS $message) {
					$html[$field_name] = $message;
				}
			}
			return response()->json(['errors'=>$html]);
		}

        if($request->has('is_social') && $request->is_social == 1){
            $password = str_random(8);
        }
        else{
            $password = $request->password;
        }

        $user               = new User;
		$user->name 		= $request->firstname;
		$user->last_name 	= $request->lastname;
		$user->email 		= $request->email;
		$user->password 	= Hash::make($password);
		$user->user_type 	= 2;
        $user->status       = 4;
        $user->balance      = 0;

        $user->activation_token = md5(uniqid(mt_rand(), true));

		if($user->save()){
            $user = $user->toArray();
             
            try {
                Mail::send('emails.userspass', $user, function ($message) use ($user) {
                    $message->to($user['email'], $user['name'])->subject('Thank you for registering on Lucky Draw App');
                });
            }
            catch(Exception $e){
                return response()->json(['error'=>$e->getMessage()]);
            }

			return response()->json(['status'=>'true', 'data'=>$user]);
		}
		else{
			return response()->json(['status'=>'false']);
		}
	}

    /**
     * Resend activation email to the user having the specific email address
     * @param  Request $request for $enail
     * @author Akhilesh Shukla
     **/
    public function resendEmail(Request $request){
        $email  = $request->email;
        $user   = User::where('email', $email)->first();
        $user   = $user->toArray();
         
        try {
            Mail::send('emails.userspass', $user, function ($message) use ($user) {
                $message->to($user['email'], $user['name'])->subject('Thank you for registering on Lucky Draw App');
            });
        }
        catch(Exception $e){
            return response()->json(['error'=>$e->getMessage()]);
        }

        return response()->json(['status'=>'true', 'data'=>$user]);
    }

	/**
	 * API Login User
	 * @author Vikas
	 * @modified Akhilesh Shukla, May 30 2016
	 **/
	public function login(Request $request)
	{
		$email 		= $request->email;
		$password 	= $request->password;
        $device_id  = $request->device_id;
		$user 		= User::where('email', $email)->first();
        
        if($user) {
            
            if($user->status == 2){
                return response()->json(['error'=>'Your account has been deactivated by admin.']);
            }
            elseif($user->status == 4){
                return response()->json(['error'=>'Your account activation is pending. Please activate your account! Please click OK to resend activation email.', 'activation' => 1]);
            }
            elseif($user->status == 3){
                return response()->json(['error'=>'Your account has been deleted by admin.']);
            }

            if(Hash::check($password, $user->password)) {
                $user->api_token = str_random(60);
                $user->save();

                \DB::table('gcm_user')->where('gcm_regid', $device_id)->update(['email' => $email]);
                return response()->json($user);
            }
            else {
                return response()->json(['error'=>'Incorrect Password!']);
            }
        }
        
        return response()->json(['error'=>'User does not exist!']);
    }

    /**
     * Social Login for User
     * @author Akhilesh Shukla
     **/
    public function socialLogin(Request $request)
    {
        $email 		= $request->email;
        $user 		= User::where('email', $email);

        if($user->count() > 0){
            $user               = $user->first();
            $user->api_token    = str_random(60);
            $user->update();
            $user->isFirst      = 0;
        }
        else{
            $user               = new User;
            $user->email        = $email;
            $user->user_type 	= 2;
			$user->status 	    = 1;
			$user->balance 	    = 0;
            $user->api_token    = str_random(60);
            $user->save();
            $user->isFirst      = 1;
        }

        return response()->json($user);
    }

    /**
	 * API Logout User
	 * @author Vikas
	 **/
	public function logout(Request $request){
		$id 		= $request->id;
		$api_token 	= $request->password;
		$user 		= User::find($id);

		$user->api_token = '';
		$user->update();

		return response()->json(['msg'=>'Logout Successful!', 'status'=>200]);
    }

    /**
     * Check if a choice is available for the dice game
     * @author Akhilesh Shukla
     **/
    public function choice_available($choice, $drawId)
    {
        $availability = true;
        $participants = Participant::where('luckydraw_id', $drawId)->get();
        
        foreach ($participants as $participant) {
            if($participant->choice == $choice){
                $availability = false;
            }
        }
        
        return $availability;
    }

    /**
     * Implements user participation in a draw
     * @author Akhilesh Shukla
     **/
    public function participants(Request $request)
    {
        $id             = $request->id;
        $luckydraw_id   = $request->luckydraw_id;

        $activeDraw     = Draws::find($luckydraw_id);
        $drawType       = Managedraw::find($activeDraw->drawid);
        $user           = User::find($id);

        // If it is a coin toss
        if($drawType->type == 1){

            // If this is the 1st entry
            if($activeDraw->participants == 0){
                $user->balance  = $user->balance - $drawType->price;
                $user->update();

                // Add entry to participants table
                $participant = new Participant;
                $participant->user_id = $request->id;
                $participant->luckydraw_id = $request->luckydraw_id;
                $participant->choice = $request->choice;
                $participant->save();

                // Increment participant count and amount
                $activeDraw->participants += 1;
                $activeDraw->amount = (float)$activeDraw->amount + (float)$drawType->price;

                $activeDraw->update();

                return response()->json(['status'=>'200', 'data'=>$user]);
            }

            // If this is the 2nd entry
            elseif($activeDraw->participants == 1){
                // Change status and declare results if this is the 2nd entry
                $user->balance  = $user->balance - $drawType->price;
                $user->update();

                // Add entry to participants table
                $participant = new Participant;
                $participant->user_id = $request->id;
                $participant->luckydraw_id = $request->luckydraw_id;
                $firstParticipant = Participant::where('luckydraw_id', $request->luckydraw_id)->first();

                if($request->choice == $firstParticipant->choice){
                    return response()->json(['status'=>'202', 'data'=>'This choice is already taken!']);
                }
                $participant->choice = $request->choice;
                $participant->save();

                // Increment participant count and amount
                $activeDraw->participants += 1;
                $activeDraw->amount = (float)$activeDraw->amount + (float)$drawType->price;

                $activeDraw->update();

                // Declare result
                $participants = Participant::where('luckydraw_id', $activeDraw->id)->pluck('user_id');
                $participants = $participants->toArray();
                $winner       = array_rand($participants);
                
                $activeDraw->winner_id = $participants[$winner];

                // TODO: Transfer balance to winner
                $winner          = User::find($activeDraw->winner_id);
                $admin           = User::find(1);
                $profit          = $activeDraw->amount * ($activeDraw->profit_perc/100);
                $winningAmount   = $activeDraw->amount - $profit;
                $winner->balance = $winner->balance + $winningAmount;
                $admin->balance  = $admin->balance + $profit;

                $winner->update();
                $admin->update();

                $activeDraw->status = 2;
                $activeDraw->update();
                
                // TODO: Send push notification to the winner and loser
                app('App\Http\Controllers\ApiController3')->sendPushNotification($winner->email, $activeDraw->id, $winningAmount);
                app('App\Http\Controllers\ApiController3')->sendLoserPushNotification($activeDraw->id, $drawType->price, $winningAmount);

                // TODO: Check if draw type has not been deleted
                if($drawType->status == 1){
                    // TODO: Create a new instance of this draw
                    $newDraw                = new Draws;
                    $newDraw->drawid        = $drawType->id;
                    $newDraw->amount        = 0;
                    $newDraw->participants  = 0;
                    $newDraw->type          = 1;
                    $newDraw->status        = 1;
                    $newDraw->winner_id     = 0;
                    $newDraw->priority      = $drawType->priority;
                    $newDraw->profit_perc   = $drawType->profit;
                    $newDraw->save();
                }

                return response()->json(['status' => '200', 'data' => $user, 'winner' => $winner]);
            }
            else{
                // There are already 2 participants and result is declared
                return response()->json(['status' => '203', 'data'=>'Toss already over!']);
            }
        }
        
        elseif ($drawType->type == 2) {
            // If it is a dice game
            if($activeDraw->participants == 0){
                $user->balance  = $user->balance - $drawType->price;
                $user->update();

                // Add entry to participants table
                $participant = new Participant;
                $participant->user_id = $request->id;
                $participant->luckydraw_id = $request->luckydraw_id;
                $participant->choice = $request->choice;
                $participant->save();


                // Increment participant count and amount
                $activeDraw->participants += 1;
                $activeDraw->amount = (float)$activeDraw->amount + (float)$drawType->price;

                $activeDraw->update();
                $activeDraw->amount = ($activeDraw->amount*$activeDraw->profit_perc)/100;

                return response()->json(['status'=>'200', 'data'=>$user]);
            }

            elseif($activeDraw->participants < 5){
                // check if choice is available
                if($this->choice_available($request->choice, $request->luckydraw_id)){
                    // Change status and declare results if this is the 2nd-5th entry
                    $user->balance  = $user->balance - $drawType->price;
                    $user->update();

                    // Add entry to participants table
                    $participant                = new Participant;
                    $participant->user_id       = $request->id;
                    $participant->luckydraw_id  = $request->luckydraw_id;
                    $participant->choice        = $request->choice;
                    $participant->save();
                    
                    // Increment participant count and amount
                    $activeDraw->participants  += 1;
                    $activeDraw->amount         = (float)$activeDraw->amount + (float)$drawType->price;
                    $activeDraw->update();
                    $activeDraw->amount = ($activeDraw->amount*$activeDraw->profit_perc)/100;

                    return response()->json(['status' => '200', 'data' => $user]);
                }
                else{
                    return response()->json(['status'=>'201', 'data'=>'This choice has been already taken. Please choose another option!']);
                }
                
            }
            elseif($activeDraw->participants == 5){
                // If this is the 6th and final participant for the dice game
                // check if choice is available
                if($this->choice_available($request->choice, $request->luckydraw_id)){
                    // Change status and declare results if this is the 2nd-5th entry
                    $user->balance  = $user->balance - $drawType->price;
                    $user->update();

                    // Add entry to participants table
                    $participant                = new Participant;
                    $participant->user_id       = $request->id;
                    $participant->luckydraw_id  = $request->luckydraw_id;
                    $participant->choice        = $request->choice;
                    $participant->save();
                    
                    // Increment participant count and amount
                    $activeDraw->participants  += 1;
                    $activeDraw->amount         = (float)$activeDraw->amount + (float)$drawType->price;
                    $activeDraw->update();
                    $activeDraw->amount = ($activeDraw->amount*$activeDraw->profit_perc)/100;

                    // Declare result
                    $participants = Participant::where('luckydraw_id', $activeDraw->id)->pluck('user_id');
                    $participants = $participants->toArray();
                    $winner       = array_rand($participants);
                    
                    $activeDraw->winner_id = $participants[$winner];

                    // TODO: Transfer balance to winner
                    $winner          = User::find($activeDraw->winner_id);
                    $admin           = User::find(1);
                    $profit          = $activeDraw->amount * ($activeDraw->profit_perc/100);
                    $winningAmount   = $activeDraw->amount - $profit;
                    $winner->balance = $winner->balance + $winningAmount;
                    $admin->balance  = $admin->balance + $profit;

                    $winner->update();
                    $admin->update();

                    $activeDraw->status = 2;
                    $activeDraw->update();
                    
                    // TODO: Send push notification to the winner and loser
                    app('App\Http\Controllers\ApiController3')->sendPushNotification($winner->email, $activeDraw->id, $winningAmount);
                    app('App\Http\Controllers\ApiController3')->sendLoserPushNotification($activeDraw->id, $drawType->price, $winningAmount);

                    // TODO: Check if draw type has not been deleted
                    if($drawType->status == 1){
                        // TODO: Create a new instance of this draw
                        $newDraw                = new Draws;
                        $newDraw->drawid        = $drawType->id;
                        $newDraw->amount        = 0;
                        $newDraw->participants  = 0;
                        $newDraw->type          = 2;
                        $newDraw->status        = 1;
                        $newDraw->winner_id     = 0;
                        $newDraw->priority      = $drawType->priority;
                        $newDraw->profit_perc   = $drawType->profit;
                        $newDraw->save();
                    }

                    return response()->json(['status' => '200', 'data' => $user, 'winner' => $winner]);
                }
                else{
                    return response()->json(['status'=>'201', 'data'=>'This choice has been already taken. Please choose another option!']);
                }
            }
            else{
                // There are already 6 participants and result is declared
                return response()->json(['status' => '203', 'data'=>'Game already over!']);
            }

        }

        else{

            $diff = $activeDraw->created_at->diffInSeconds(Carbon::now(), false);

            if($diff <= 6){
                return response()->json(['data'=>'elapsed', 'diff'=> $diff]);
            }
            //$admin = User::find(1);

            // Deduct balance from user's wallet and add it to admin's wallet
            if($user->balance >= $drawType->price) {
                $count = Participant::where('user_id', $id)->where('luckydraw_id', $luckydraw_id)->count();

                //if($count == 0){
                    $user->balance  = $user->balance - $drawType->price;
                    $user->update();

    
                    //$admin->balance = $admin->balance + $drawType->price;
                    //$admin->update();

                    // Add entry to participants table
                    $participant = new Participant;
                    $participant->user_id = $request->id;
                    $participant->luckydraw_id = $request->luckydraw_id;
                    // $participant->save();

                    // Increment participant count and amount
                    $activeDraw->participants += 1;
                    $activeDraw->amount = (float)$activeDraw->amount + (float)$drawType->price;

                    $activeDraw->update();
                /*}
                else{
                    return response()->json(['status'=>'203', 'data'=>'Already participated!']);
                }*/
            }
            else{
                return response()->json(['status'=>'202', 'data'=>'Unsuccessful']);
            }
            
            if($participant->save()){
                return response()->json(['status'=>'200', 'data'=>$user, 'diff'=> $diff]);
            }
        }
    }

    /**
	 * API Forgot Password (Reset password and email new one to the user)
	 * @author Vikas Sharma
     * @modified Akhilesh Shukla - May 24, 2016
	 **/
	public function forgotpass(Request $request)
    {
		$email  = $request->email;
		$user   = User::where('email', $email)->first();

        if($user){
            $newPass        = str_random(8);
            $user->password = Hash::make($newPass);
            //$user->reset_token = str_random(32);
            $user->update();

            $user = $user->toArray();
            $user['newPassword'] = $newPass;

            try {
                Mail::send('emails.usersforgotpass', $user, function ($message) use ($user) {
                    $message->to($user['email'], $user['name'])->subject('Your New Password');
                });
            }
            catch(Exception $e){
                //echo $e->getMessage();
                //echo 'New Password: '. $newPass;
                return response()->json(['error'=>$e->getMessage()]);
            }

            unset($user['newPassword']);

            return response()->json(['status' => 200, 'message'=> 'Password Reset and Emailed Successfully', 'data' => $user]);
        }
        else{
            return response()->json(['status' => 202, 'message'=> 'User not found! Please check the email!']);
        }
	}

    /**
     * THIS METHOD IS NOT IS USE ANYMORE
     * Reset password based on reset_token mechanism
     * @param $token
     * @param $password
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
	public function resetPassword($token, $password)
    {
		$user = User::where('reset_token', $token)->first();
		$user->password = Hash::make($password);
		$user->reset_token = '';
		$user->update();
		return response()->json($user);
	}

	/**
	 * API Profle
	 * @author Vikas
	 **/
	public function postprofile(Request $request)
    {
		$data = $request->all();
		$userinfo = User::find($request->id);
        
		if(count($userinfo)>0){
			$userinfo->name = $data['firstname'];
            $userinfo->username = $data['username'];
			$userinfo->phone = $data['phone'];
			$userinfo->paypal_id = $data['mode_cash'];
			$userinfo->address = $data['address'];
			// $userinfo->email = $data['email'];
			$userinfo->update();
		}
		
		return response()->json($userinfo);
	}

	/**
	 * API Profile
	 * @author Vikas
	 **/
	public function showprofile(Request $request)
    {
		$user = User::find($request->id);
		return response()->json($user);
	}

	/**
     * Function to Change User password
	 * @author Vikas
	 **/
	public function changepass(Request $request)
	{
		$data       = $request->all();
		$email 		= $request->email;
		$password 	= $request->password;
		$oldpass 	= $request->oldpass;

		$user = User::where('email', $email)->first();

		if(Hash::check($oldpass, $user->password)){
			$user->password = Hash::make($password);
			$user->update();
			return response()->json(['status'=>'200', 'data'=>$user]);
		}
		else{
			return response()->json(['status'=>'202', 'data'=>'Error: Old password does not match!']);
		}
		
	}

    /**
     * API Sharing
     * @author Vikas
     **/
    public function sharing()
    {
        $share = Share::first();
        $share->image = url(config('constants.profileImage') . $share->image);
        return response()->json($share);
    }

    /**
     * API Paypal ID and Secret key
     * @author Vikas
     **/
    public function getpaypal(Request $request)
    {
        $id 		= $request->id;
        $user 		= User::find($id);

        return response()->json(['userid'=>$user->id, 'paypal_id'=>$user->paypal_id, 'paypal_secret_key'=>$user->paypal_secret_key]);
    }

    /**
     * Return the current logged in user object based on API auth
     * @return Object $user
     * @author Akhilesh Shukla
     **/
    public function getUser(){
        $user = Auth::guard('api')->user();
        return response()->json($user);
    }

    /**
	 * Pin Digits Register API
	 * @author Vikas
	 **/
	public function pinreg(Request $request) {
        

        $data = $request->all();
		//dd($data);

        $rules = array(
            'mpin'  => 'required',
			'email' => 'required|email',
        );

		$messages = array(
			'required'  => 'This field is required',
			'email'     => 'Please enter a valid email address',
		);

		$validator = Validator::make($data, $rules, $messages);
				
		if ($validator->fails()){
			$html = array();
			foreach($validator->messages()->getMessages() as $field_name => $messages) {
				// Go through each message for this field.
				foreach($messages AS $message) {
					$html[$field_name] = $message;
				}
			}
			return response()->json(['errors'=>$html]);
		}
        //print_r($request);exit;
        //$user  = print_r($request)->email;
		$user = User::where('email',$data['email'])->first();

		if($user){
			$user->mpin  = Hash::make($request->mpin);
			$user->update();
		}
          
        $user = $user->toArray();

        try {
            Mail::send('emails.userpinsetup', $user, function ($message) use ($user) {
                $message->to($user['email'], $user['name'])->subject('Pin Setup');
            });
        }
        catch(Exception $e){
            //echo $e->getMessage();
            //echo 'New Pin: '. $newPin;
            return response()->json(['error'=>$e->getMessage()]);
        }

		
		return response()->json($user);

		
	}

	/**
	 * Pin Digits Check API
	 * @author Vikas
	 **/
	public function checkmpin(Request $request) {
        $user = User::where('email',$request->email)->first();
		
		if(Hash::check($request->mpin, $user->mpin)) {
            return response()->json($user);
        }
        else {
            return response()->json(['error'=>'Incorrect Pin!']);
        }
	}

	 /**
	 * API Forgot Pin (Reset Pin and email new one to the user)
	 * @author Vikas Sharma
	 **/
	public function forgotpin(Request $request)
    {
        $email      = $request->email;
		$password   = $request->password;
		
        $user       = User::where('email', $email)->first();

        if($user){

            if(Hash::check($password, $user->password)){
                $newPin        = mt_rand(0,4);
                $user->mpin = Hash::make($newPin);
                //$user->reset_token = str_random(32);
                $user->update();

                $user = $user->toArray();
                $user['newPindi'] = $newPin;

                try {
                    Mail::send('emails.userforgotpin', $user, function ($message) use ($user) {
                        $message->to($user['email'], $user['name'])->subject('Your New Pin');
                    });
                }
                catch(Exception $e){
                    //echo $e->getMessage();
                    //echo 'New Pin: '. $newPin;
                    return response()->json(['error'=>$e->getMessage()]);
                }

                unset($user['newPindi']);

                return response()->json(['status' => 200, 'message'=> 'Pin Reset and Emailed Successfully', 'data' => $user]);
            }
            else{
                return response()->json(['status' => 201, 'message'=> 'Wrong Password!']);
            }
        }
        else{
            return response()->json(['status' => 202, 'message'=> 'User not found! Please check the email!']);
        }
    }



   public function resetmpin(Request $request)
    {
        $email  = $request->email;
        $pin    = $request->mpin;
        $user   = User::where('email', $email)->first();

        if($user){ 
            $user->mpin = Hash::make($pin);
            $user->update();
            $user =  $user->toArray();

            try {
                Mail::send('emails.userresetpin', $user, function ($message) use ($user) {
                    $message->to($user['email'], $user['name'])->subject('Pin Reset Successful!');
                });
            }
            catch(Exception $e){
                //echo $e->getMessage();
                //echo 'New Pin: '. $newPin;
                return response()->json(['error'=>$e->getMessage()]);
            }

            return response()->json(['status' => 200, 'message'=> 'Pin Reset Successfully', 'data' => $user]);
        }
         
        else{
            return response()->json(['status' => 202, 'message'=> 'User not found!']);
        }
	}

   /* public function haspin()
    {

        $pin = '1234';
        $hashedPin = Hash::make($pin);
        echo $hashedPin;
    }*/

    /**
     * API Get faq
     * @author Vikas Sharma
     **/
    public function getfaq()
    {
        $faqs  = Faq::where('status', 1)->get();
        foreach ($faqs as $faq) {
            $faq->title = strip_tags($faq->title);
            $faq->description = strip_tags($faq->description);
        }
        return response()->json($faqs);
    }
    
    /**
     * API Contact form Submissions
     * @author Vikas Sharma
     **/
    //Function Submit Contact Us Form
    public function apicontactus(Request $request)
    {
        $data = $request->all();
        $rules = array(
            'name' => 'required',
            'email' => 'required|email',
            'message' => 'required',
        );
        $validator = Validator::make($data, $rules);
        
        if ($validator->fails()){
            $html = array();
            foreach($validator->messages()->getMessages() as $field_name => $messages) {
                // Go through each message for this field.
                foreach($messages AS $message) {
                    $html[]= $message;
                }
            }
            $response['status'] = 'error';
            $response['message'] =  $html;
            return json_encode($response);
        }
        else{
            $Contactform = new Feedback;
            $Contactform->name = $data['name'];
            $Contactform->email = $data['email'];
            $Contactform->message = $data['message'];
            $Contactform->save();
            $message = "Thanks for contacting us! We will get back to you soon.";
            
            $Contactform   = $Contactform->toArray();
        
        try {
            Mail::send('emails.usersfeed', $Contactform, function ($message) use ($Contactform) {
                $message->to($Contactform['email'], $Contactform['name'])->subject('Thank you for feedback on Lucky Draw App');
            });
        }
        catch(Exception $e){
            return response()->json(['error'=>$e->getMessage()]);
        }

            $response['status'] = 200;
            $response['message'] = $message;
            return response()->json($response);
        }
    }
    
    /**
     * Get Get Mpin Url
     * @return \Illuminate\Http\JsonResponse
     * @author Vikas Sharma
     **/
    public function getpinurl(Request $request)
    {
        $email  = $request->email;
        $api_token = User::where('email', $email)->first();
        return response()->json(['api_token'=>$api_token]);
    }

    /**
     * Get details of Game Rules
     * @return \Illuminate\Http\JsonResponse
     * @author Vikas Sharma
     **/

    public function game()
    {
        $data  = Gamerules::first();
        return response()->json(['title'=>$data->title, 'description'=> $data->description]);
    }

    /**
     * Deactivate User Account
     * @return \Illuminate\Http\JsonResponse
     * @author Vikas Sharma
     **/
    public function passdeactive(Request $request){
        $user_id   =   $request->id;
        $password  =   $request->password;
        $user      =   User::find($user_id);

        if($user){
            if(Hash::check($password, $user->password)){
                $user->status = 2;
                $user->save();
                return response()->json(['status'=>200, 'data'=>$user]);
            }   
            else{
                return response()->json(['status' => 202, 'error'=> 'Incorrect Password!']);
            }
        }
        else{
            return response()->json(['error'=> 'No user found!']);
        }
    }
}