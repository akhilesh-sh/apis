<?php

namespace App\Http\Controllers;

use App\Transaction;
use App\User;
use App\Draws;
use App\Managedraw;
use App\Notification;
use App\Participant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Auth;
use Mail;
use DB;
use Validator;
use Hash;
use Session;
// use Request;


/**
 * @author Akhilesh Shukla
 **/
class ApiController3 extends Controller 
{

    /**
     * Return all the results for a given user
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function userResults(Request $request)
    {

        $user           = User::find($request->id);
        $participants   = Participant::where('user_id', $user->id)->with('draw')->groupBy('luckydraw_id')->groupBy('user_id')->orderBy('id', 'DESC')->paginate(10);
        $results        = array();

        if(count($participants) > 0){
            $i = 0;
            foreach($participants as $participant) {
                $drawType = Managedraw::find($participant->draw->drawid);
                
                if($drawType){
                    $results['data'][$i]['drawid']        = $participant->luckydraw_id;
                    $results['data'][$i]['type']          = $participant->draw->type;
                    $results['data'][$i]['amount']        = $participant->draw->amount - ($participant->draw->amount * ($participant->draw->profit_perc/100));
                    $results['data'][$i]['participants']  = $participant->draw->participants;
                    $results['data'][$i]['price']         = $drawType->price;
                    $results['data'][$i]['timestamp']     = $participant->draw->updated_at->format('j M Y, h:i a');

                    if($participant->draw->winner_id == $user->id){
                        $results['data'][$i]['result'] = 'WINNER';
                    }
                    elseif($participant->draw->status != 2 && $participant->draw->status != 3){
                        $results['data'][$i]['result'] = 'IN PROCESS';
                    }
                    elseif($participant->draw->status == 3){
                        $results['data'][$i]['result'] = 'REFUNDED';
                        $results['data'][$i]['amount'] = $participant->draw->amount;
                    }
                    else{
                        $results['data'][$i]['result'] = 'UNLUCKY';
                    }
                }
                
                $i++;
            }
            // echo '<pre>';
            // print_r($participants); exit;
            $results['next_page_url'] = $participants->nextPageUrl();
        }
        else{
            return response()->json(['error'=>'No Results found!']);
        }

        return response()->json($results);
    }

    /**
     * Return all the results for a all user
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function allResults(Request $request)
    {
        $user       = User::find($request->id);
        $draws      = Draws::where('status', 2)->where('participants', '!=', 0)->where('winner_id', '!=', 0) /*->where('winner_id', '!=', 0)*/
                        ->orderBy('id', 'DESC')->paginate(10);
        $results    = array();

        if(count($draws) > 0){
            $i = 0;
            foreach($draws as $draw) {
                $drawType = Managedraw::find($draw->drawid);

                if($drawType){
                    
                    $results['data'][$i]['drawid']        = $draw->id;
                    $results['data'][$i]['type']          = $draw->type;
                    $results['data'][$i]['amount']        = $draw->amount - ($draw->amount * ($draw->profit_perc/100));
                    $results['data'][$i]['participants']  = $draw->participants;
                    $results['data'][$i]['price']         = $drawType->price;
                    $results['data'][$i]['timestamp']     = $draw->updated_at->format('j M Y, h:i a');

                    if($draw->winner_id == 0 || $draw->status == 3){
                        $results['data'][$i]['result'] = 'REFUNDED';
                        $results['data'][$i]['amount'] = $draw->amount;
                        unset($results['data'][$i]);
                    }
                    if($draw->participants == 0){
                        $results['data'][$i]['result'] = 'NO PARTICIPANTS';
                        unset($results['data'][$i]);
                    }
                    else{
                        $winner = User::find($draw->winner_id);
                        if($winner)
                        $results['data'][$i]['result'] = empty($winner->username) ? $winner->name .' '. $winner->last_name : $winner->username;
                    }
                }
                $i++;
            }
            // echo '<pre>';
            // print_r($participants); exit;
            $results['next_page_url'] = $draws->nextPageUrl();
        }
        else{
            return response()->json(['error'=>'No Results found!']);
        }

        return response()->json($results);
    }

    /**
     * Return the specified user's balance
     * @author Akhilesh Shukla
     **/
    public function getBalance(Request $request){
    	$user = User::find($request->userId);
    	return response()->json($user);
    }

    /**
     * List all transactions for the given user
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function transactions(Request $request)
    {
        $id = $request->id;
        $transactions = Transaction::where('userid', $id)->orderBy('id', 'desc')->get();

        foreach ($transactions as $transaction) {
            $transaction->created = $transaction->created_at->format('j M Y, h:i a');
        }

        if(count($transactions)){
            return response()->json(['message'=>'Success!', 'data' => $transactions]);
        }
        else{
            return response()->json(['message'=>'No data found!']);
        }
    }

    /**
     * Verify password for the given user
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function verifyPassword(Request $request)
    {
        $password   = $request->password;
        $id         = $request->id;
        $user       = User::find($id);
        
        if(Hash::check($password, $user->getPassword())){
            return response()->json(['status'=>200, 'message'=>'Correct Password!']);
        }
        return response()->json(['status'=>202, 'message'=>'Wrong password!']);
    }
    
    /**
     * Deposit an amount to user's balance
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function submitForUser(Request $request)
    {
        $data = $request->all();
        Log::info('These are paypal parameters: '. print_r($data, true));

        $id         = $request->id;
        $amount     = $request->amount;
        $paypal     = $request->paypalRes;

        // Find and update user balance
        $user       = User::find($id);

        $user->balance  = (float) $user->balance + (float) $amount;

        if($user->update()){
            $transaction = new Transaction;
            $transaction->userid = $id;
            $transaction->amount = $amount;
            $transaction->type   = 1;
            $transaction->payment_id = $paypal['response']['id'];
            $transaction->status = 1;
            $transaction->save();

            $mailData = array(
                    'type'          => 'Deposit',
                    'email'         => $user->email,
                    'name'          => $user->name, 
                    'referenceid'   => $transaction->id,
                    'amount'        => $transaction->amount, 
                    'transactionid' => $transaction->payment_id, 
                    'created_at'    => $transaction->created_at
                );

            try {
                Mail::send('emails.usertransaction', $mailData, function ($message) use ($mailData) {
                    $message->to($mailData['email'], $mailData['name'])->subject('Your transaction details');
                });
            }
            catch(Exception $e){
                //echo $e->getMessage();
                //echo 'New Password: '. $newPass;
                return response()->json(['error'=>$e->getMessage()]);
            }

            return response()->json(['status'=>200, 'message'=>'User balance updated', 'data'=>$user]);
        }
        else{
            return response()->json(['status'=>202, 'message'=>'Error encountered! Please try again.', 'data'=>$user]);
        }
    }

    /**
     * Withdraw an amount from user's balance
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function withdrawForUser(Request $request)
    {
        $id         = $request->id;
        $user       = User::find($id);
        $amount     = $request->amount;

        if(floatval($amount) < 1){
            return response()->json(['status' => 203, 'message' => 'Please enter a valid amount!']);
        }

        if($user->balance >= $amount) {
            // Process actual paypal transaction
            $env     = $user->paypal_env;
            if(trim($user->paypal_id) != ''){

                $payment = $this->payoutWithPaypal($id, $user->paypal_id, $amount, $env);

                if($payment['success'] == 1){
                    // update user balance
                    $user->balance = (float)$user->balance - (float)$amount;
                    $user->update();
                    return response()->json(['status' => 200, 'message' => 'Withdrawal Successful!', 'data' => $user]);
                }
                else {
                    return response()->json(['status' => 202, 'message' => 'Error encountered! Please try again.', 'data' => $user]);
                }
            }
            else{
                return response()->json(['status' => 202, 'message' => 'Please enter paypal ID first!.', 'data' => $user]);
            }
        }
        else {
            return response()->json(['status' => 202, 'message' => 'Insufficient funds. Please enter an amount less than: '.$user->balance, 'data' => $user]);
        }
	}

    /**
     * Get bearer token from paypal
     * @return json response
     * @author Akhilesh Shukla
     **/
    public function getBearerToken($env)
    {

        if($env == 1){
            $paypalURL = config('constants.paypalURL') . 'v1/oauth2/token';
        }
        else{
            $paypalURL = config('constants.sandboxURL') . 'v1/oauth2/token';
        }

        $paypalKey = config('constants.paypalKey');
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL               => $paypalURL,
            CURLOPT_RETURNTRANSFER    => true,
            CURLOPT_ENCODING          => "",
            CURLOPT_MAXREDIRS         => 10,
            CURLOPT_TIMEOUT           => 30,
            CURLOPT_HTTP_VERSION      => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST     => "POST",
            CURLOPT_POSTFIELDS        => "grant_type=client_credentials",
            CURLOPT_HTTPHEADER        => array(
                "accept: application/json",
                "accept-language: en_US",
                "authorization: Basic $paypalKey",
                "cache-control: no-cache",
                "content-type: application/x-www-form-urlencoded"
            ),
        ));

        $response   = curl_exec($curl);
        $err        = curl_error($curl);

        curl_close($curl);

        $result = array();
        
        if($err){
            $result['error'] = "cURL Error #:" . $err;
        }
        else{
            $result['response'] = json_decode($response, true);
            //return response()->json($r);
        }
        
        return $result;
    }

    /**
     * Get bearer token from paypal
     * @return json response
     * @author Akhilesh Shukla
     **/
    public function payoutWithPaypal($userId, $paypalId, $amount, $env)
    {

        if($env == 1){
            $paypalURL = config('constants.paypalURL') . 'v1/payments/payouts?sync_mode=true';
        }
        else{
            $paypalURL = config('constants.sandboxURL') . 'v1/payments/payouts?sync_mode=true';
        }
        $bearerKey = $this->getBearerToken($env);
        //Log::info('bearer object'. print_r($bearerKey, true));

        if($bearerKey['response']){
            $key = $bearerKey['response']['access_token'];

            $data = [
                'sender_batch_header' => [
                    'email_subject' => 'You have a payment!'
                ],
                'items' => [
                    [
                        'recipient_type'=>'EMAIL', 
                        'amount'=>[
                            'value'     => ($amount - ($amount * 0.02)),
                            'currency'  => 'USD'
                        ], 
                        'receiver'=> $paypalId, //'anshul.gupta-buyer@envisionecommerce.com',
                        'note'=> 'LuckyDraw payment withdrawal by client',
                    ]
                ]
            ];

            $data = json_encode($data);

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL               => $paypalURL,
                CURLOPT_RETURNTRANSFER    => true,
                CURLOPT_ENCODING          => "",
                CURLOPT_MAXREDIRS         => 10,
                CURLOPT_TIMEOUT           => 30,
                CURLOPT_HTTP_VERSION      => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST     => "POST",
                CURLOPT_POSTFIELDS        => $data,
                CURLOPT_HTTPHEADER        => array(
                    "content-type: application/json",
                    "authorization: Bearer $key",
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if($err){
                return ['error'=> 'Error encountered while processing payment!', 'success'=> 0];
            }
            else{
                $response                   = json_decode($response, true);
                //print_r($response); exit;
                $transaction                = new Transaction;
                $transaction->type          = 2;
                $transaction->status        = $response['items'][0]['transaction_status'];
                $transaction->userid        = $userId;
                $transaction->amount        = $amount;
                $transaction->amt_value     = $response['items'][0]['payout_item']['amount']['value'];
                $transaction->payment_id    = isset($response['items'][0]['transaction_id'])?$response['items'][0]['transaction_id']:'';

                $transaction->payout_item_id    = isset($response['items'][0]['payout_item_id'])?$response['items'][0]['payout_item_id']:'';
                $transaction->processing_fee    = isset($response['items'][0]['payout_item_fee']['value'])?$response['items'][0]['payout_item_fee']['value']:'';
                
                $transaction->save();

                if($response['items'][0]['transaction_status'] == 'FAILED'){
                    return ['error'=> 'Error encountered while processing payment!', 'success'=> 0];
                }

                $user = User::find($userId);

                $mailData = array(
                        'type'              => 'Withdrawal',
                        'email'             => $user->email,
                        'name'              => $user->name, 
                        'referenceid'       => $transaction->id,
                        'amount'            => $transaction->amount, 
                        'transactionid'     => $transaction->payment_id,
                        'payout_item_id'    => $transaction->payout_item_id,
                        'processing_fee'    => ((float) $transaction->amount - (float) $transaction->amt_value),
                        'amt_value'         => $transaction->amt_value,
                        'created_at'        => $transaction->created_at
                    );

                try {
                    Mail::send('emails.usertransaction2', $mailData, function ($message) use ($mailData) {
                        $message->to($mailData['email'], $mailData['name'])->subject('Your transaction details');
                    });
                }
                catch(Exception $e){
                    //echo $e->getMessage();
                    //echo 'New Password: '. $newPass;
                    return response()->json(['error'=>$e->getMessage()]);
                }

                return ['success'=> 1, 'error'=> 0];
            }

            //return response()->json(json_decode($response));
        }
    }

    /**
     * Update push DB after login
     * @author Akhilesh Shukla
     */
    public function pushRegUser(Request $request)
    {
        $arr = array(
            'device_type'   => $request->device_type,
            'gcm_regid'     => $request->gcm_regid,
            'email'         => 'undefined'
        );

        if(DB::table('gcm_user')->insert($arr)){
            return response()->json(['status' => 200, 'message' => 'Push record updated!']);
        }

        return response()->json(['status' => 202, 'message' => 'Update failed!']);
    }

    /**
     * Get all the new notifications after notification having id $id
     * @param $id
     * @param $instituteid
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function getLatestNotifications($email, $id){
        $notifications = Notification::where(function ($query) use($email, $id) {
                            $query->where('email', $email)->orWhere('email', 'all');
                        })
                        ->where('id', '>', $id)->get();
        if(count($notifications) > 0){
            $message = 'yes';
        }
        else{
            $message = 'no';
        }
        return response()->json(['message' => $message, 'notifications' => $notifications]);
    }

    /**
     * Get the last notification for a given device id $deviceId
     * @param $instituteid
     * @return \Illuminate\Http\JsonResponse
     * @author Akhilesh Shukla
     **/
    public function getLastNotification($email){
        $notifications = array(Notification::where('email', $email)->orWhere('email', 'all')->orderBy('id', 'desc')->first());
        return response()->json($notifications);
    }
    
    /**
     * Run cron everyMinute via routes
     * @author Akhilesh Shukla
     **/   
    public function cronEveryMinute()
    {
        // Check previously running Lucky Draws and create new draw of that type if one is finished
        // Announce winner of the finished draw
        // Transfer balance to the winner's wallet
        // $now = time();
        // TODO: Check all active draws to announce winner
        $activeDraws = Draws::where('status', 1)->where('winner_id', 0)->where('type', 0)->get();

        if(count($activeDraws) > 0) {

            foreach ($activeDraws as $activeDraw) {
                // Log::info('Differences: ' . $activeDraw->created_at->diffInMinutes());
                $drawType = Managedraw::find($activeDraw->drawid);

                if ($activeDraw->created_at->diffInMinutes() >= $drawType->timeframe) {
                    // TODO: Announce winner of this draw
                    $participants = Participant::where('luckydraw_id', $activeDraw->id)->pluck('user_id');

                    if(count($participants) > 0) {
                        $participants = $participants->toArray();
                        $participants = array_values(array_unique($participants));
                        // print_r($participants); exit;
                        // Log::info('Participants: \n' . print_r($participants, true));
                        // If more than one user has participated in this draw
                        if(count($participants) > 1){
                            $winner = array_rand($participants);
                            $activeDraw->winner_id = $participants[$winner];

                            // TODO: Transfer balance to winner
                            $winner          = User::find($activeDraw->winner_id);
                            $admin           = User::find(1);
                            $profit          = $activeDraw->amount * ($activeDraw->profit_perc/100);
                            $winningAmount   = $activeDraw->amount - $profit;
                            $winner->balance = $winner->balance + $winningAmount;
                            $admin->balance  = $admin->balance + $profit;

                            $winner->update();
                            $admin->update();

                            $activeDraw->winner_id  = $winner->id;
                            $activeDraw->status     = 2;
                            $activeDraw->update();
                            
                            // TODO: Send push notification to the winner
                            $this->sendPushNotification($winner->email, $activeDraw->id, $winningAmount);
                            $this->sendLoserPushNotification($activeDraw->id, $drawType->price, $winningAmount);
                        }
                        else{
                            // if only one user has participated one or more times
                            // refund full amount
                            $participant = User::find($participants[0]);
                            $participant->balance += $activeDraw->amount;
                            $participant->update();

                            $activeDraw->status = 3; // status 3 is for refunded draw
                            $activeDraw->update();

                            $this->sendPushNotification($participant->email, $activeDraw->id, $activeDraw->amount, true);
                        }
                    }
                    else{
                        $activeDraw->status = 2;
                        $activeDraw->update();
                    }

                    // TODO: Check if draw type has not expired or deleted
                    $now = time();
                    if($drawType->status == 1 && $drawType->startdate <= $now && $drawType->enddate >= $now - 86400){
                        // TODO: Create a new instance of this draw
                        $newDraw                = new Draws;
                        $newDraw->drawid        = $drawType->id;
                        $newDraw->amount        = 0;
                        $newDraw->participants  = 0;
                        $newDraw->status        = 1;
                        $newDraw->winner_id     = 0;
                        $newDraw->profit_perc   = $drawType->profit;
                        $newDraw->save();
                        //Log::info('New draw created with id: '.$newDraw->id);
                    }
                }

                //Log::info('Winner announce for last remaining active draw of type:'.$activeDraw->drawid);
            }
        }


        $now = time();
        $drawTypes = Managedraw::where('status', 1)->where('type', 0)->where('startdate', '<=', $now)->where('enddate', '>=', $now - 86400)->get();

        // Check all drawTypes against active draws to see if a new draw needs to be created for any drawType
        if(count($drawTypes) > 0){
            foreach($drawTypes as $drawType){
                $activeDraws = Draws::where('drawid', $drawType->id)->where('status', 1)->where('winner_id', 0)->count();
                if($activeDraws == 0){
                    $newDraw                = new Draws;
                    $newDraw->drawid        = $drawType->id;
                    $newDraw->amount        = 0;
                    $newDraw->participants  = 0;
                    $newDraw->status        = 1;
                    $newDraw->winner_id     = 0;
                    $newDraw->priority      = $drawType->priority;
                    $newDraw->profit_perc   = $drawType->profit;
                    $newDraw->save();
                    //Log::info('New draw created with id: '.$newDraw->id);
                }
            }
        }

        //Log::info('This is some useful information.');
    }

    /**
     * Run cron everyDay via routes
     * @author Akhilesh Shukla
     **/   
    public function cronEveryDay()
    {
        echo 'Go get some work done!!';

        $now = time();

        // For coin toss
        $drawTypes = Managedraw::where('status', 1)->where('type', 1)->where('startdate', '<=', $now)->where('enddate', '>=', $now - 86400)->get();

        foreach ($drawTypes as $drawType) {
            $count = $drawType->getActiveDrawCount();
            if($count == 0){
                $newDraw                = new Draws;
                $newDraw->drawid        = $drawType->id;
                $newDraw->amount        = 0;
                $newDraw->participants  = 0;
                $newDraw->status        = 1;
                $newDraw->winner_id     = 0;
                $newDraw->type          = 1;
                $newDraw->priority      = $drawType->priority;
                $newDraw->profit_perc   = $drawType->profit;
                $newDraw->save();
            }
        }

        // For dice game
        $drawTypes = Managedraw::where('status', 1)->where('type', 2)->where('startdate', '<=', $now)->where('enddate', '>=', $now - 86400)->get();

        foreach ($drawTypes as $drawType) {
            $count = $drawType->getActiveDrawCount();
            if($count == 0){
                $newDraw                = new Draws;
                $newDraw->drawid        = $drawType->id;
                $newDraw->amount        = 0;
                $newDraw->participants  = 0;
                $newDraw->status        = 1;
                $newDraw->winner_id     = 0;
                $newDraw->type          = 2;
                $newDraw->priority      = $drawType->priority;
                $newDraw->profit_perc   = $drawType->profit;
                $newDraw->save();
            }
        }
    }

    /**
     * Send a push notification and store it to database
     * @author Akhilesh Shukla
     */
    public function sendPushNotification($email, $drawId, $amt, $isRefund=false){
        //$data  = $request->all();
        $users = \DB::table('gcm_user')->where('email', $email)->get();

        $registrationIds = array();
        $AppleIds = array();

        if(count($users)>0){
            foreach($users as $user){
                if($user->gcm_regid!='' && strtolower($user->device_type)!='ios'){
                    $registrationIds[] = trim($user->gcm_regid);
                }
                if($user->gcm_regid!='' && strtolower($user->device_type)=='ios'){
                    $AppleIds[] = trim($user->gcm_regid);
                }
            }
        }

        if (!empty($registrationIds) || !empty($AppleIds)){
            if (!empty($registrationIds)){
                $notification['email']       = $email;
                
                if($isRefund){
                    $notification['title']       = 'Refunded!';
                    $notification['message']     = 'Your money for your participation in luckydraw ID: '.$drawId.' - $'.$amt.' has been refunded as no other players had joined the room.';
                }
                else{
                    $notification['title']       = 'Congratulations!';
                    $notification['message']     = 'You have won the luckydraw ID: '.$drawId.' with a winning amount of $'. $amt;
                }

                $notification['created_at']  = date('Y-m-d H:i:s');
                $notification['updated_at']  = date('Y-m-d H:i:s');

                \DB::table('notifications')->insert($notification);

                // prep the bundle
                $largeicon = url('/resources/assets/images/logo.png');
                $smallIcon = url('/resources/assets/images/logo.png');

                $msg = array(
                    'title'         => $notification['title'],
                    'subtitle'      => '$'.$amt,
                    'tickerText'    => 'Lucky Draw Notification',
                    'vibrate'       => 1,
                    'sound'         => 1,
                    'largeIcon'     => $largeicon,
                    'smallIcon'     => $smallIcon,
                    'message'       => $notification['message'],
                );
                
                $fields = array(
                    'registration_ids'  => $registrationIds,
                    'data'          => $msg
                );

                $headers = array(
                    'Authorization: key=AIzaSyAi-WlPWQvpnun4m5i5DYUQ80rU8q7fC2g',//Server Key
                    'Content-Type: application/json'
                );

                $ch = curl_init();
                curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
                curl_setopt( $ch,CURLOPT_POST, true );
                curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
                curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
                curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
                curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
                $result = curl_exec($ch );
                curl_close( $ch );
            }
            if(!empty($AppleIds)){
                foreach($AppleIds as $AppleId){
                    // our token
                    $deviceToken = $AppleId;

                    // The password for the .pem file
                    $passphrase = 'Envision@123';

                    // The push message
                    $message = $notification['message'];

                    $ctx = stream_context_create();
                    //We specify the path to .pem certificate we created
                    stream_context_set_option($ctx, 'ssl', 'local_cert', app_path('Http/Controllers/ApplePushCer/Certificates_GymApp_Dev.pem'));
                    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

                    // Open connection with APNS
                    $fp = stream_socket_client(
                        'ssl://gateway.sandbox.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

                    if (!$fp) {
                        Session::flash('message', "Error connection: $err $errstr");
                        return redirect('/admin/pushnotification');
                    }


                    // We create the payload
                    $body['aps'] = array(
                        'alert' => $message,
                        'sound' => 'bingbong.aiff',
                        'badge' => 1
                    );

                    // Json Format
                    $payload = json_encode($body);

                    // We build the binary message
                    $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

                    // We sent
                    $result = fwrite($fp, $msg, strlen($msg));

                    if (!$result) {
                        Session::flash('message', 'Push Notification Not Sent');
                        return redirect('/admin/pushnotification');
                    }
                    // close the connection
                    fclose($fp);
                }
            }
            Session::flash('message', 'Push Notification Sent Successfully !');
        }
        else{
            Session::flash('message', 'No Device ID Found');
        }

        return redirect('/admin/pushnotification');
    }

    /**
     * Send a push notification and store it to database
     * @author Akhilesh Shukla
     */
    public function sendLoserPushNotification($drawId, $price, $amt){
        //$data  = $request->all();
        // Get winner id
        
        $draw = Draws::find($drawId);
        $winnerId = $draw->winner_id;

        $ids = Participant::where('luckydraw_id', $drawId)->where('user_id', '!=', $winnerId)->pluck('user_id')->toArray();
        $ids = array_values($ids);
        
        $emails = User::whereIn('id', $ids)->pluck('email')->toArray();

        $users = \DB::table('gcm_user')->whereIn('email', $emails)->get();
        //dd($users);

        $registrationIds = array();
        $AppleIds = array();

        if(count($users)>0){
            foreach($users as $user){
                if($user->gcm_regid!='' && strtolower($user->device_type)!='ios'){
                    $registrationIds[] = trim($user->gcm_regid);
                }
                if($user->gcm_regid!='' && strtolower($user->device_type)=='ios'){
                    $AppleIds[] = trim($user->gcm_regid);
                }
            }
        }

        if (!empty($registrationIds) || !empty($AppleIds)){
            if (!empty($registrationIds)){
                foreach($emails as $email){
                    $notification['email']       = $email;
                    $notification['title']       = 'Hard Luck!';
                    $notification['message']     = 'You lost the luckydraw ID: '.$drawId.' (cost: '.$price.'). Better luck next time!';
                    $notification['created_at']  = date('Y-m-d H:i:s');
                    $notification['updated_at']  = date('Y-m-d H:i:s');

                    \DB::table('notifications')->insert($notification);
                }

                // prep the bundle
                $largeicon = url('/resources/assets/images/logo.png');
                $smallIcon = url('/resources/assets/images/logo.png');

                $msg = array(
                    'title'         => 'Hard Luck!',
                    'subtitle'      => 'Better Luck Next Time!',
                    'tickerText'    => 'Lucky Draw Notification',
                    'vibrate'       => 1,
                    'sound'         => 1,
                    'largeIcon'     => $largeicon,
                    'smallIcon'     => $smallIcon,
                    'message'       => $notification['message'],
                );
                
                $fields = array(
                    'registration_ids'  => $registrationIds,
                    'data'          => $msg
                );

                $headers = array(
                    'Authorization: key=AIzaSyAi-WlPWQvpnun4m5i5DYUQ80rU8q7fC2g',//Server Key
                    'Content-Type: application/json'
                );

                $ch = curl_init();
                curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
                curl_setopt( $ch,CURLOPT_POST, true );
                curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
                curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
                curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
                curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
                $result = curl_exec($ch );
                curl_close( $ch );
            }
            if(!empty($AppleIds)){
                foreach($AppleIds as $AppleId){
                    // our token
                    $deviceToken = $AppleId;

                    // The password for the .pem file
                    $passphrase = 'Envision@123';

                    // The push message
                    $message = $notification['message'];

                    $ctx = stream_context_create();
                    //We specify the path to .pem certificate we created
                    stream_context_set_option($ctx, 'ssl', 'local_cert', app_path('Http/Controllers/ApplePushCer/Certificates_GymApp_Dev.pem'));
                    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

                    // Open connection with APNS
                    $fp = stream_socket_client(
                        'ssl://gateway.sandbox.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

                    if (!$fp) {
                        Session::flash('message', "Error connection: $err $errstr");
                        return redirect('/admin/pushnotification');
                    }


                    // We create the payload
                    $body['aps'] = array(
                        'alert' => $message,
                        'sound' => 'bingbong.aiff',
                        'badge' => 1
                    );

                    // Json Format
                    $payload = json_encode($body);

                    // We build the binary message
                    $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

                    // We sent
                    $result = fwrite($fp, $msg, strlen($msg));

                    if (!$result) {
                        //Session::flash('message', 'Push Notification Not Sent');
                        //return redirect('/admin/pushnotification');
                    }
                    // close the connection
                    fclose($fp);
                }
            }
            //Session::flash('message', 'Push Notification Sent Successfully !');
        }
        else{
            //Session::flash('message', 'No Device ID Found');
        }

    }
}