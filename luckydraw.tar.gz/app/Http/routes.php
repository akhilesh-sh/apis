<?php

Route::get('/', function () {
    if(!Auth::user()){
        return redirect('/admin/login');
    }
    else{
        return redirect('/admin/dashboard');
    }
});

Route::get('/admin/login', function(){
    return view('admin.login');
});

Route::get('/admin/login', function () {
    return view('admin.login');
});

Route::post('/admin/postlogin', 'LoginController@postSignin');
Route::get('/logout', 'LoginController@logout');
Route::any('/getBearerToken', 'ApiController3@payoutWithPaypal');

//Route for admin area
Route::group(['middleware' => 'auth', 'prefix' => 'admin'], function(){
    //Admin panel
    Route::get('dashboard', function(){
        return View::make('admin.dashboard');
    });

    //show Users Table Page
    Route::get('/manageusers', 'AdminController@manageusers');
    Route::get('/manageusersajax', 'AdminController@manageusersajax');
    Route::post('/updateusersstatus', 'AdminController@updateusersstatus');

    //Create new users
    Route::get('/createnewusers', 'AdminController@createnewusers');
    Route::post('/createnewusers', 'AdminController@postcreatenewusers');
    Route::post('/checkexisringuserpassword', 'AdminController@checkexisringuserpassword');
    Route::post('/checkexisringuser', 'AdminController@checkexisringuser');

    //show Profile Page
    Route::get('/manageprofile', 'AdminController@manageprofile');
    Route::post('/manageprofile', 'AdminController@updateprofile');

    //Manage Draw
    Route::get('/managedraw', 'AdminController@managedraw');
    Route::get('/managedrawajax', 'AdminController@managedrawajax');
    Route::get('/managedrawajax2', 'AdminController@managedrawajax2');
    Route::get('/managedrawajax3', 'AdminController@managedrawajax3');
    Route::post('/adddrawajax', 'AdminController@adddrawajax');
    Route::post('/updatedrawstatus', 'AdminController@updatedrawstatus');
    Route::post('/updatedrawajax', 'AdminController@updatedrawajax');
    Route::post('/editdrawajax', 'AdminController@editdrawajax');

    //Manage Draw Results
    Route::get('/managedrawresults', 'AdminController@managedrawresults');
    Route::get('/managedrawresultsajax', 'AdminController@managedrawresultsajax');
    Route::post('/updateresultsstatus', 'AdminController@updateresultsstatus');

    //Manage Draws
    Route::get('/draws', 'AdminController@draws');
    Route::get('/drawsajax', 'AdminController@drawsajax');
    Route::post('/updateddrawsstatus', 'AdminController@updateddrawsstatus');

    //Manage Account History
    Route::get('/accounthistory', 'AdminController@accounthistory');
    Route::get('/accounthistoryajax', 'AdminController@accounthistoryajax');
    Route::post('/updatedaccountstatus', 'AdminController@updatedaccountstatus');

    //Manage Transation Section
    Route::get('/managetransaction', 'AdminController@managetransaction');
    Route::get('/managetransactionajax', 'AdminController@managetransactionajax');
    Route::post('/updatedtransactionstatus', 'AdminController@updatedtransactionstatus');

    //Manage Invoices Section
    Route::get('/manageinvoices', 'AdminController@manageinvoices');
    Route::get('/manageinvoicesajax', 'AdminController@manageinvoicesajax');
    Route::post('/updatedinvoicesstatus', 'AdminController@updatedinvoicesstatus');

    //show Share Page
    Route::get('/manageshare', 'AdminController@manageshare');
    Route::post('/manageshare', 'AdminController@updateshare');

    //Manage terms and condition
    Route::get('/termscondition',['as'=>'conditions','uses'=>'AdminController@termsCondition']);
    Route::post('/terms',['as'=>'termscondtion','uses'=>'AdminController@terms']);

   
    /*Route::get('/faq', 'AdminController@faq');
    Route::post('/faq', 'AdminController@postfaq');*/
     //show Faq Page
    Route::get('/faq', 'AdminController@faq');
    Route::get('/faqajax', 'AdminController@faqajax');
    Route::post('/addfaqajax', 'AdminController@addfaqajax');
    Route::post('/updatedfaqstatus', 'AdminController@updatedfaqstatus');
    Route::post('/updatedfaqajax', 'AdminController@updatedfaqajax');
    Route::post('/editfaqajax', 'AdminController@editfaqajax');
    Route::any('/updatepriorityajax', 'AdminController@updatepriorityajax');

    //show Settings Page
    Route::get('/settings', 'AdminController@settings');
    Route::post('/settings', 'AdminController@updatesettings');

    //Show Game Rules Section
    Route::get('/gamerules', 'AdminController@gamerules');
    Route::post('/gamerules', 'AdminController@updategamerules');

    // Contact form Submission
    Route::get('/contactUsSubmissions', 'AdminController@contactUsSubmissions');
    Route::any('/contactUsSubmissionsAjax', 'AdminController@contactUsSubmissionsAjax');
    Route::any('/contactUsSubmissions/details/{id}', 'AdminController@submissionDetails');

    // PUSH Notification
    Route::get('/pushnotification', 'AdminController@pushnotification');
    Route::post('/sendpushnotification', 'AdminController@sendpushnotification');
});

Route::any('reset-password/{token}/{password}','ApiController@resetPassword');
Route::any('cronEveryMinute','ApiController3@cronEveryMinute');
Route::any('cronEveryDay','ApiController3@cronEveryDay');
Route::get('activation/{token}', 'AdminController@activationtoken');
Route::get('sendLoserPushNotification/{drawid}/{price}/{amt}', 'ApiController3@sendLoserPushNotification');


//API  Section
Route::group(['prefix' => 'api'], function(){
    Route::any('/pushRegUser','ApiController3@pushRegUser');
    Route::any('/resendEmail','ApiController@resendEmail');
    Route::any('/getLastNotification/{email}','ApiController3@getLastNotification');
    Route::any('/getLatestNotifications/{email}/{id}','ApiController3@getLatestNotifications');
    Route::post('/forgotpass','ApiController@forgotpass');
    Route::post('/socialLogin','ApiController@socialLogin');
    Route::post('/changepass','ApiController@changepass');
    Route::post('/getpinurl','ApiController@getpinurl');
    Route::post('/apicontactus', 'ApiController@apicontactus');
    Route::post('/getTerms','ApiController2@getTerms');
    Route::post('/registerUser', 'ApiController@registerUser');
    Route::any('/pinreg', 'ApiController@pinreg');
    Route::any('/checkmpin', 'ApiController@checkmpin');
    Route::post('/passdeactive', 'ApiController@passdeactive');
    Route::any('resetmpin', 'ApiController@resetmpin');
    Route::post('/forgotpin','ApiController@forgotpin');
    Route::post('/login', 'ApiController@login');
    Route::post('/sharing', 'ApiController@sharing');
    Route::get('/faq', 'ApiController@getfaq');
    Route::get('/game', 'ApiController@game');
    Route::post('/getBalance', 'ApiController3@getBalance');

    Route::get('/getpaypal', 'ApiController@getpaypal');
    // Route::any('/activeDice','ApiController2@activeDice');
    Route::group(['middleware' => 'auth:api'], function(){
        Route::post('/verifyPassword','ApiController3@verifyPassword');
        Route::post('/getUser', 'ApiController@getUser');
        Route::post('/drawDetails','ApiController2@drawDetails');
        Route::any('/deposit', 'ApiController3@submitForUser');
        Route::post('/postprofile','ApiController@postprofile');
        Route::post('/showprofile','ApiController@showprofile');
        Route::post('/transactions', 'ApiController3@transactions');
        Route::post('/activeDraws','ApiController2@activeDraws');
        Route::post('/activeDice','ApiController2@activeDice');
        Route::post('/activeToss','ApiController2@activeToss');
        Route::any('/results', 'ApiController3@userResults');
        Route::any('/allResults', 'ApiController3@allResults');
        Route::post('/logout', 'ApiController@logout');
        Route::post('/participants', 'ApiController@participants');
        Route::post('/withdraw', 'ApiController3@withdrawForUser');

    });
});