<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gamerules extends Model
{
    
	 /*
     * The database table used by the model.
     *
     * @var string
    
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'gamerules';

	
	
}
