<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{
    
	 /*
     * The database table used by the model.
     *
     * @var string
    
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'faq';

    /*public function managedraw(){
        return $this->belongsTo('App\Managedraw', 'drawid', 'id');
    }*/
	
	
}
