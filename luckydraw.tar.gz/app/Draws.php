<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Draws extends Model
{
    
	 /*
     * The database table used by the model.
     *
     * @var string
    
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'draws';

    public function managedraw(){
        return $this->belongsTo('App\Managedraw', 'drawid', 'id');
    }
	
	
}
