<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Termcondition extends Model
{
    
	 /*
     * The database table used by the model.
     *
     * @var string
    
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'termcondition';
	
	
}
