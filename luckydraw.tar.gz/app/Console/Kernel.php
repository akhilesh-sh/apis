<?php

namespace App\Console;

use App\Draws;
use App\Managedraw;
use App\User;
use App\Participant;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use Illuminate\Support\Facades\Log;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        // Commands\Inspire::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        /*$schedule->call(function () { // Test cron job
            Log::info('This is some useful information.');
        })->everyMinute();*/

        $schedule->call(function () {
            // Check previously running Lucky Draws and create new draw of that type if one is finished
            // Announce winner of the finished draw
            // Transfer balance to the winner's wallet
            $now = time();
            $drawTypes = Managedraw::where('status', 1)->where('startdate', '<=', $now)->where('enddate', '>=', $now)->get();
            foreach($drawTypes as $drawType){
                $activeDraws = Draws::where('drawid', $drawType->id)->where('status', 1)->where('winner_id', 0);

                if($activeDraws->count() > 0) {
                    $activeDrawss = $activeDraws->get();
                    foreach ($activeDrawss as $activeDraw) {
                        Log::info('Differences: ' . $activeDraw->created_at->diffInMinutes());
                        if ($activeDraw->created_at->diffInMinutes() >= $drawType->timeframe) {
                            // TODO: Announce winner of this draw
                            $participants = Participant::where('luckydraw_id', $activeDraw->id)->pluck('user_id');

                            if(count($participants) > 0) {
                                $participants = $participants->toArray();
                                Log::info('Participants: \n' . print_r($participants, true));
                                $winner = array_rand($participants);
                                $activeDraw->winner_id = $participants[$winner];

                                // TODO: Transfer balance to winner
                                $winner          = User::find($activeDraw->winner_id);
                                $admin           = User::find(1);
                                $profit          = $activeDraw->amount * ($activeDraw->profit_perc/100);
                                $winningAmount   = $activeDraw->amount - $profit;
                                $winner->balance = $winner->balance + $winningAmount;
                                $admin->balance  = $admin->balance + $profit;

                                $winner->update();
                                $admin->update();
                            }

                            $activeDraw->status = 2;
                            $activeDraw->update();


                            // TODO: Create a new draw
                            $newDraw                = new Draws;
                            $newDraw->drawid        = $drawType->id;
                            $newDraw->amount        = 0;
                            $newDraw->participants  = 0;
                            $newDraw->status        = 1;
                            $newDraw->winner_id     = 0;
                            $newDraw->profit_perc   = $drawType->profit;
                            $newDraw->save();
                            Log::info('New draw created with id: '.$newDraw->id);
                        }
                    }
                }
                else{
                    // TODO: If no draws of this type are active, create a new active draw of this type
                    $newDraw                = new Draws;
                    $newDraw->drawid        = $drawType->id;
                    $newDraw->amount        = 0;
                    $newDraw->participants  = 0;
                    $newDraw->status        = 1;
                    $newDraw->winner_id     = 0;
                    $newDraw->profit_perc   = $drawType->profit;
                    $newDraw->save();
                    Log::info('New draw created with id: '.$newDraw->id);
                }
            }
            Log::info('This is some useful information.');
        })->everyMinute();
    }
}
