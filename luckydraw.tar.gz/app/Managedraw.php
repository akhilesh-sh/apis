<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Draws;

class Managedraw extends Model
{
    
	 /*
     * The database table used by the model.
     *
     * @var string
    
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'managedraw';
	
    public function getActiveDrawCount(){
        return Draws::where('status', 1)->where('drawid', $this->id)->count();
    }
	
}
