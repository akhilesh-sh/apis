<!DOCTYPE html>
<html lang="en"><head>
		<title>{{ config('constants.appName') }} - Dashboard</title>

		<!-- BEGIN META -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="your,keywords">
		<meta name="description" content="Short explanation about this website">
		<!-- END META -->

		<!-- BEGIN STYLESHEETS -->
		<link href='http://fonts.googleapis.com/css?family=Roboto:300italic,400italic,300,400,500,700,900' rel='stylesheet' type='text/css'/>
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/bootstrap.css" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/materialadmin.css" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/font-awesome.min.css" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/material-design-iconic-font.min.css" />
        
        <link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/bootstrap-datepicker/datepicker3.css" />
        <link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/jquery-ui/jquery-ui-theme.css" />
	
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/rickshaw/rickshaw.css" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/morris/morris.core.css" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/main-style.css" />
        <link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/DataTables/TableTools.css" />
        <link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css" />
    	<link rel="stylesheet" type="text/css" href="{{ Request::root() }}/resources/assets/backend/css/magnific-popup.css" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/customstyle.css" />
		
		<!-- END STYLESHEETS -->

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script type="text/javascript" src="../assets/js/libs/utils/html5shiv.js?1403934957"></script>
		<script type="text/javascript" src="../assets/js/libs/utils/respond.min.js?1403934956"></script>
		
		<![endif]-->
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/jquery/jquery-1.11.2.min.js"></script>
        <script src="{{ Request::root() }}/resources/assets/backend/js/jquery.magnific-popup.js"></script>
		
		
	</head>
	<body class="menubar-hoverable header-fixed">
	<?php $currentpagepath = Request::path(); ?>
		<!-- BEGIN HEADER-->
		<header id="header" >
			<div class="headerbar">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="headerbar-left">
					<ul class="header-nav header-nav-options">
						<li class="header-nav-brand" >
							<div class="brand-holder">
								<a href="{{ Request::root() }}/admin/dashboard">
									<span class="text-lg text-bold text-primary">{{ config('constants.appName') }}</span>
								</a>
							</div>
						</li>
						<li>
							<a class="btn btn-icon-toggle menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
								<i class="fa fa-bars"></i>
							</a>
						</li>
					</ul>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="headerbar-right">
					<?php /*?><ul class="header-nav header-nav-options">
						<li>
							<!-- Search form -->
							<form class="navbar-search" role="search">
								<div class="form-group">
									<input type="text" class="form-control" name="headerSearch" placeholder="Enter your keyword">
								</div>
								<button type="submit" class="btn btn-icon-toggle ink-reaction"><i class="fa fa-search"></i></button>
							</form>
						</li>
						
						
					</ul><!--end .header-nav-options --><?php */?>
					<ul class="header-nav header-nav-profile">
						<li class="dropdown">
							<a href="javascript:void(0);" class="dropdown-toggle ink-reaction" data-toggle="dropdown">
								<img class="pull-left" src="<?php if(Auth::user()->image==''){?>{{ Request::root() }}/resources/assets/uploads/nophoto_user.png<?php }else{echo Request::root().'/resources/assets/uploads/'.  Auth::user()->image;}?>" alt="" />
								<span class="pull-left"  style="margin-left:7px;" class="profile-info">
									{{ Auth::user()->name }} {{ Auth::user()->last_name }}
                                    <br>
									<small><?php if(Auth::user()->user_type==1){ echo "Administrator";}?></small>
								</span>
							</a>
							
							<ul class="dropdown-menu animation-dock">
									<?php /*?><li class="dropdown-header">Config</li><?php */?>
									<li><a href="{{ Request::root() }}/admin/manageprofile">My profile</a></li>
								<li><a href="{{ Request::root() }}/logout"><i class="fa fa-fw fa-power-off text-danger"></i> Logout</a></li>
							</ul><!--end .dropdown-menu -->
						</li><!--end .dropdown -->
					</ul><!--end .header-nav-profile -->
					<?php /*?><ul class="header-nav header-nav-toggle">
						<li>
							<a class="btn btn-icon-toggle btn-default" href="#offcanvas-search" data-toggle="offcanvas" data-backdrop="false">
								<i class="fa fa-ellipsis-v"></i>
							</a>
						</li>
					</ul><<?php */?>
				</div><!--end #header-navbar-collapse -->
			</div>
		</header>
		<!-- END HEADER-->

		<!-- BEGIN BASE-->
		<div id="base">
		<!-- BEGIN CONTENT-->
        <div id="content">
          @yield('content')
        </div>  
		  <!--end #content-->
			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN MENUBAR-->
			<div id="menubar" class="menubar-inverse ">
				<div class="menubar-fixed-panel">
					<div>
						<a class="btn btn-icon-toggle btn-default menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
							<i class="fa fa-bars"></i>
						</a>
					</div>
					<div class="expanded">
						<a href="../html/dashboards/dashboard.html">
							<span class="text-lg text-bold text-primary ">MATERIAL&nbsp;ADMIN</span>
						</a>
					</div>
				</div>
				<div class="menubar-scroll-panel">

                     @if(Auth::user()->user_type=='1')
					
					<!-- BEGIN MAIN MENU -->
					<ul id="main-menu" class="gui-controls">

						<!-- BEGIN DASHBOARD -->
						<li  @if($currentpagepath == 'admin/dashboard') class="active" @endif>
							<a href="{{ Request::root()}}/admin/dashboard">
								<div class="gui-icon"><i class="md md-home"></i></div>
								<span class="title">Dashboard</span>
							</a>
						</li><!--end /menu-li -->
						<!-- END DASHBOARD -->
						<li  @if($currentpagepath == 'admin/manageusers') class="active" @endif>
							<a href="{{ Request::root()}}/admin/manageusers">
								<div class="gui-icon">
                                	<span class="fa fa-users"></span>
                                </div>
								<span class="title">Manage Users</span>
							</a>
						</li><!--end /menu-li -->
                       
					   
					   <li  @if($currentpagepath == 'admin/managedraw') class="active" @endif>
							<a href="{{ Request::root()}}/admin/managedraw">
								<div class="gui-icon">
                                	<span class="fa fa-list"></span>
                                </div>
								<span class="title">Manage Draws</span>
							</a>
						</li><!--end /menu-li -->

						 <li  @if($currentpagepath == 'admin/managedrawresults') class="active" @endif>
							<a href="{{ Request::root()}}/admin/managedrawresults">
								<div class="gui-icon">
                                	<span class="md md-web"></span>
                                </div>
								<span class="title">Draw Results</span>
							</a>
						</li><!--end /menu-li -->

                         <li  @if($currentpagepath == 'admin/draws') class="active" @endif>
							<a href="{{ Request::root()}}/admin/draws">
								<div class="gui-icon">
                                	<span class="md md-assessment"></span>
                                </div>
								<span class="title">Active Draws</span>
							</a>
						</li><!--end /menu-li -->
                        
                        
                        <!--<li  @if($currentpagepath == 'admin/accounthistory') class="active" @endif>
							<a href="{{ Request::root()}}/admin/accounthistory">
								<div class="gui-icon">
                                	<span class="fa fa-puzzle-piece fa-fw"></span>
                                </div>
								<span class="title">Manage Account History</span>
							</a>
						</li><!--end /menu-li -->

		
                         <li  @if($currentpagepath == 'admin/managetransaction') class="active" @endif>
							<a href="{{ Request::root()}}/admin/managetransaction">
								<div class="gui-icon">
                                	<span class="md md-payment"></span>
                                </div>
								<span class="title">Manage Transaction</span>
							</a>
						</li><!--end /menu-li -->

						
						 <!--<li  @if($currentpagepath == 'admin/manageinvoices') class="active" @endif>
							<a href="{{ Request::root()}}/admin/manageinvoices">
								<div class="gui-icon">
                                	<span class="fa fa-list"></span>
                                </div>
								<span class="title">Manage Invoices</span>
							</a>
						</li><!--end /menu-li -->


						

						<li  @if($currentpagepath == 'admin/manageshare') class="active" @endif>
							<a href="{{ Request::root()}}/admin/manageshare">
								<div class="gui-icon">
                                	<span class="fa md-share"></span>
                                </div>
								<span class="title">Manage Sharing</span>
							</a>
						</li>

						<li  @if($currentpagepath == 'admin/termscondition') class="active" @endif>
							<a href="{{ Request::root()}}/admin/termscondition">
								<div class="gui-icon">
                                	<span class="fa md-view-module "></span>
                                </div>
								<span class="title">Terms & Condition</span>
							</a>
						</li>

                       <li  @if($currentpagepath == 'admin/faq') class="active" @endif>
							<a href="{{ Request::root()}}/admin/faq">
								<div class="gui-icon">
                                	<span class="fa md-label-outline "></span>
                                </div>
								<span class="title">FAQ</span>
							</a>
						</li>

						<li  @if($currentpagepath == 'admin/gamerules') class="active" @endif>
							<a href="{{ Request::root()}}/admin/gamerules">
								<div class="gui-icon">
                                	<span class="fa md-gamepad "></span>
                                </div>
								<span class="title">Game Rules</span>
							</a>
						</li>

						<li  @if($currentpagepath == 'admin/settings') class="active" @endif>
							<a href="{{ Request::root()}}/admin/settings">
								<div class="gui-icon">
                                	<span class="fa md-settings-applications"></span>
                                </div>
								<span class="title">Settings</span>
							</a>
						</li>

                        <li  @if($currentpagepath == 'admin/contactUsSubmissions') class="active" @endif>
							<a href="{{ Request::root()}}/admin/contactUsSubmissions">
								<div class="gui-icon">
                                	<span class="md md-message"></span>
                                </div>
								<span class="title">Contact Form Submissions</span>
							</a>
						</li><!--end /menu-li -->

						<li @if($currentpagepath == 'admin/pushnotification') class="active" @endif>
                            <a href="{{ url('/admin/pushnotification') }}">
                                <div class="gui-icon"><i class="fa fa-bell"></i></div>
                                <span class="title">Push Notification</span>
                            </a>
                        </li>
						<!--end /menu-li -->

						<!-- BEGIN lI Static Pages-->
						</ul>
						
						@else
						
						<ul id="main-menu" class="gui-controls">
						<!-- BEGIN DASHBOARD -->
						<li>
							<a href="{{ Request::root() }}/admin/dashboard" class="active">
								<div class="gui-icon"><i class="md md-home"></i></div>
								<span class="title">Dashboard</span>
							</a>
						</li><!--end /menu-li -->
						
						
					</ul>
					
					@endif
				
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS RIGHT -->

		</div><!--end #base-->
		<!-- END BASE -->

		<!-- BEGIN JAVASCRIPT -->
		
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/jquery/jquery-migrate-1.2.1.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/bootstrap/bootstrap.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/spin.js/spin.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/autosize/jquery.autosize.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/moment/moment.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/flot/jquery.flot.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/flot/jquery.flot.time.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/flot/jquery.flot.resize.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/flot/jquery.flot.orderBars.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/flot/jquery.flot.pie.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/flot/curvedLines.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/jquery-knob/jquery.knob.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/sparkline/jquery.sparkline.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/nanoscroller/jquery.nanoscroller.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/d3/d3.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/d3/d3.v3.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/rickshaw/rickshaw.min.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/source/App.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/source/AppNavigation.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/source/AppOffcanvas.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/source/AppCard.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/source/AppForm.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/source/AppNavSearch.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/source/AppVendor.js"></script>
		<?php /*?><script src="{{ Request::root() }}/resources/assets/backend/js/core/demo/Demo.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/js/core/demo/DemoFormComponents.js"></script>
		<script src="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/bootstrap-datepicker/datepicker3.css"></script><?php */?>
		
		<!-- END JAVASCRIPT -->

	</body>
</html>
