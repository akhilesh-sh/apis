@extends('adminlayout')
@section('content')

<style>
	.section-body{
	margin-left: 50px;
	margin-right:50px;
	}
.card .form-group{ margin:20px;}	
	
</style>		
						

<section>
		<div class="section-body">
			<div class="row">
                <div class="col-sm-10 pull-left">
                    <h3 class="nomargin text-primary">Manage Profile</h3>
                </div>
            </div>
            <hr>
			<!-- BEGIN VERTICAL FORM -->
			<div class="row">
				<div class="col-lg-12">
					<article class="margin-bottom-xxl">
						@if(Session::has('message'))
							 <p class="alert alert-info">{{ Session::get('message') }}</p>
						@endif
						@if($errors->has())
							@foreach ($errors->all() as $error)
							 	<p class="lead text-danger">{{ $error }}</p>
							@endforeach
						@endif
					</article>
				</div><!--end .col -->
				
				<div class="col-lg-12">
					<form id="profileform" class="form" enctype="multipart/form-data" accept-charset="UTF-8" action="{{ Request::root() }}/admin/manageprofile" method="POST">
						<div class="card">
							<div class="card-head style-primary">
								<header>Admin Profile</header>
							</div>
                            
                            
                    
	           <div style="clear:both;"></div>
			
			                 <div class="form-group floating-label">
			                 @if($Userinfo->image)
							 <img style="width:150px; height:150px;" src="{{ Request::root() }}/resources/assets/uploads/{{ $Userinfo->image }}" >
							 @else
							 <img style="width:150px; height:150px;" src="{{ Request::root() }}/resources/assets/uploads/nophoto_user.png" >
							 @endif
                                <input type="file" class="form-control" name="image" value="">
								
                             </div>
			                 
							 
                             <div class="form-group floating-label">
                                <input type="text" class="form-control" name="name" value="{{ $Userinfo->name }}">
								<label>First Name</label>
                             </div>
							 
							  <div class="form-group floating-label">
                                <input type="text" class="form-control" name="last_name" value="{{ $Userinfo->last_name }}">
								<label>Last Name</label>
                             </div>
							 
							 <div class="form-group floating-label">
                                <input type="Password" class="form-control" name="currpass" >
								<label>Current Password</label>
                             </div>
							 
                             <div class="form-group floating-label">
                                <input type="Password" name="pass" value="" class="form-control">
                                <label>New Password</label>
                             </div>
                             
							 
							 <div class="form-group floating-label">
                                <input type="Password" id="cpass" name="cpass" value="" class="form-control">
                                <label>Confirm Password</label>
                             </div>  

                              <div class="form-group floating-label">
                                <input type="text" id="paypal_id" name="paypal_id" value="{{ $Userinfo->paypal_id }}" class="form-control">
                                <label>Paypal ID</label>
                             </div> 

                             <!--  <div class="form-group floating-label">
                                <input type="text" id="paypal_secret_key" name="paypal_secret_key" value="{{ $Userinfo->paypal_secret_key }}" class="form-control">
                                <label>Paypal Secret Key</label>
                             </div>  -->                         
                             
							<div class="form-group">
								<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button class="btn btn-primary" type="submit">SAVE</button>
								</div>
                                </div>
							</div>
							
						</div><!--end .card-body -->
                        </form>
                    </div>
                </div><!--end .card -->
        
        </div><!--end .col -->
        
</section>

	<script type="text/javascript">
$(document).ready(function() {
 	$('#profileform').bootstrapValidator({
		//live:  'disabled',
		message: 'This value is not valid',
        fields: {
		 name: {
                validators: {
                    notEmpty: {
                        message: 'Name is required'
                    }
                }
            },
			
			last_name: {
                validators: {
                    notEmpty: {
                        message: 'Last Name is required'
                    }
                }
            },
			
		  currpass: {
                validators: {
					notEmpty: {
						message: 'Password is required'
					},
					remote: {
                        message:'Invalid Password',
                        url: '{{ URL::to("admin/checkexisringuserpassword")}}',
						data: function(validator, $field, value) {
                            return {
                                password: validator.getFieldElements('currpass').val()
                            };
                        },
                        type: 'POST'
                    }
                }
            },
			 	pass: {
                validators: {
					callback: {
						message:'Please provide a valid password',
						callback: function(value, validator, $field) {
							if (value === '') {
								$('#profileform').data('bootstrapValidator').enableFieldValidators('currpass', false);
								return true;
							}
							else
							{
								$('#cpass').val('');
								$('#profileform').data('bootstrapValidator').enableFieldValidators('currpass', true);
								return true;
							}
							
							 
						}
					}
                }
            },
			cpass: {
                validators: {
                    identical: {
                        field: 'pass',
                        message: 'The password and its confirm are not same'
                    }
                }
            },
		
		}
    });	
} );	

	
</script>

{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js') !!}

@stop