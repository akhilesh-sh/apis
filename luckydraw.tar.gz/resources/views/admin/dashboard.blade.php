@extends('adminlayout')
@section('content')

<style>
.row {
    margin-left: 0 !important;
    margin-right: 0 !important;
}

</style>
    <section>
        <div class="section-body">
            <div class="row">
                <!-- BEGIN ALERT - REVENUE -->
                <div class="col-md-12 col-sm-12 text-center">
                    <div class="card">
                        <div class="card-body no-padding">
                            <div class="alert alert-callout alert-info no-margin">
                                <h2 class="wlmsg">Welcome To Admin Panel</h2>
                                <?php /*?><img src="{{ Request::root() }}/resources/assets/img/banner.jpg" /><?php */?>
                            </div>
                        </div><!--end .card-body -->
                    </div><!--end .card -->
                </div><!--end .col -->
                <!-- END ALERT - REVENUE -->
            </div><!--end .row -->
        </div><!--end .section-body -->
    </section>
@stop