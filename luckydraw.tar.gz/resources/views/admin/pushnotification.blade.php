@extends('adminlayout')
@section('content')
 <link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/libs/bootstrap-colorpicker/bootstrap-colorpicker.css"/>
<style>
h1{ margin-left: 20px;}
.createuserbtn{ margin:5px;}
.tile-text { padding-right: 15px !important;}
</style>
<section>
    <div class="section-body contain-lg">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-head style-primary">
                        <header>Send Notification</header>
                    </div>
                    <div class="card-body">
                        <div class="row">
                             <div id="message">
                                @if(Session::has('message'))
                                     <p class="alert alert-info">{{ Session::get('message') }}</p>
                                @endif
                                @if($errors->has())
                                    @foreach ($errors->all() as $error)
                                        <p class="lead text-danger">{{ $error }}</p>
                                    @endforeach
                                @endif
                             </div>
                        </div>
                            <form id="notificationform" class="form" enctype="multipart/form-data" accept-charset="UTF-8" action="{{ Request::root() }}/admin/sendpushnotification" method="POST">
                                <div class="form-group floating-label">
                                    <input type="text" name="title" id="title" class="form-control">
                                    <label for="coursename">Title</label>
                                </div>

                                <div class="form-group floating-label">
                                    <textarea name="message" id="message" class="form-control" rows="3"></textarea>
                                    <label for="coursename">Message</label>
                                </div>

                                <div class="card-actionbar">
                                <div class="card-actionbar-row">
                                    <button class="btn btn-flat btn-primary ink-reaction" type="submit">Send Notification</button>
                                </div>
                                </div>
                            </form>
                    </div>
                </div>
            </div><!--end .col -->
        <!--end .col -->
        </div>
    <!--end .col -->
    <!-- END VERTICAL FORM -->
    </div>
</section>

<script type="text/javascript">
$(document).ready(function() {

 	$('#notificationform').bootstrapValidator({
		//live:  'disabled',
		message: 'This value is not valid',
        fields: {
		 	title: {
                validators: {
                    notEmpty: {
                        message: 'Title is required'
                    },
					stringLength: {
                        max: 20,
                        message: "Title can only contain 20 characters"
                  	}
                }
            },
			message: {
                validators: {
                    notEmpty: {
                        message: 'Message is required'
                    }/*,
					stringLength: {
                        max: 50,
                        message: "Message can only contain 50 characters"
                  	}*/
                }
            },	
		}
    });	
} );      
</script>
<!--Modal Box HTML for Creating New Category -->
{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/noty/packaged/jquery.noty.packaged.min.js') !!}
@stop