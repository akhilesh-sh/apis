@extends('adminlayout')
@section('content')

{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.tableTools.css') !!}
 
<style>
    h1{ margin-left: 20px;
       margin-top:20px;
    }
    /* Override feedback icon position */
    .form-horizontal .has-feedback .input-group .form-control-feedback {
        top: 0;
        right: -30px;
    }
    .tile-text { padding-right: 15px !important;}
</style>

    <section>
        <div class="section-body contain-lg">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-head style-primary">
                                <header>Submission Detail</header>
                            </div>
                            <div class="card-body">
                                <div  id="message">
                                    @if(Session::has('message'))
                                        <div class="alert alert-success"><em> {{ session('message') }}</em></div>
                                    @endif
                                    @if($errors->has())
                                        @foreach ($errors->all() as $error)
                                            <p class="lead text-danger">{{ $error }}</p>
                                        @endforeach
                                    @endif
                                </div>

                                <div class="form-group">
                                    <p>Name: {{ $submission->name }}</p>
                                </div>
                                <div class="form-group">
                                    <p>Email: {{ $submission->email }}</p>
                                </div>
                                <!-- <div class="form-group">
                                    <p>Phone: {{ $submission->requesterphone }}</p>
                                </div> -->
                                <div class="form-group">
                                    <p>Description: {{ $submission->message }}</p>
                                </div>
                                <div class="form-group">
                                    <p>Created At: {{ $submission->created_at }}</p>
                                </div>
                                <div class="form-group">
                                    <a class="btn btn-default" href="{{ url('/admin/contactUsSubmissions') }}">Back to Submission</a>
                                </div>
                            </div><!--end .card-body -->
                        </div><!--end .card -->
                </div><!--end .col -->
            </div><!--end .row -->
            <!-- END VERTICAL FORM -->
        </div>
    </section>

<!--Modal Box HTML for Creating New Category -->
{!! HTML::script('//cdn.ckeditor.com/4.5.4/full/ckeditor.js') !!}
{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.tableTools.css') !!}
{!! HTML::script('resources/assets/backend/js/noty/packaged/jquery.noty.packaged.min.js') !!}
@stop