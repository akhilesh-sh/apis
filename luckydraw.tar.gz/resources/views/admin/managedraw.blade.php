@extends('adminlayout')
@section('content')
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.tableTools.css') !!}
<style type="text/css">
.margin-bottom-xxl{margin-left:10px;}
.section-body:first-child {
    margin-top: 0px !important;
}
.text-primary {
  color: #0aa89e;
  margin:  10px 0;
}
</style>
<div id="content">    
				<section class="style-default-bright">
				<div class="section-body contain-lg">
				 <!-- BEGIN VERTICAL FORM -->
				 <div class="row">          
				 <div class="col-lg-12">
                	<div class="col-sm-10 pull-left">
                    	<h1 class="text-primary">Manage Draws</h1>
                    </div>
				 	
                    <div class="col-sm-2 pull-right">
                    	<button style="margin-top:24px;" onclick="open_addcatform()" class="btn btn-block ink-reaction btn-primary">Add Draw</button>
                    </div>
				 </div>          <!--end .col -->
				 <div class="col-lg-12 col-md-12">
				<article class="margin-bottom-xxl">
					<ul>
						<li>Edit, view or delete Draw data.</li>
					</ul>
				 </article>
				 </div>
				 <!--end .col -->
				 <div  id="message">
				@if(Session::has('message'))
							 <p class="alert alert-info">{{ Session::get('message') }}</p>
						@endif
						@if($errors->has())
							@foreach ($errors->all() as $error)
							 	<p class="lead text-danger">{{ $error }}</p>
							@endforeach
						@endif
				 </div>          
				 
				 <!-- BEGIN TABLE HOVER -->				
				 </div>        
				 
				 <!--end .row -->
						<div class="row">
							<div class="col-md-12">
							<h2 class="text-primary">Draws List</h2> 
							</div><!--end .col -->
							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="genericstable" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>ID</th>
												<th class="sort-alpha">Price</th>
												<th>Priority</th>
												<th>Start Date</th>
												<th>End Date</th>
												<th>Time Frame</th>
												<th>Profit</th>
												<th>Draw Type</th>
												<th>Status</th>
												<th>Created</th>
												<th>Action</th>
											</tr>
										</thead>
																			</table>
								</div><!--end .table-responsive -->
							</div><!--end .col -->
						</div><!--end .row -->				 
				 

              
                    <!--end .row -->
						<div class="row">
							<div class="col-md-12">
							<h2 class="text-primary">Coin Toss</h2> 
							</div><!--end .col -->
							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="genericstable2" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>ID</th>
												<th class="sort-alpha">Price</th>
												<th>Priority</th>
												<th>Start Date</th>
												<th>End Date</th>
												<th>Time Frame</th>
												<th>Profit</th>
												<th>Draw Type</th>
												<th>Status</th>
												<th>Created</th>
												<th>Action</th>
											</tr>
										</thead>
																			</table>
								</div><!--end .table-responsive -->
							</div><!--end .col -->
						</div><!--end .row -->	

						<!--end .row -->
						<div class="row">
							<div class="col-md-12">
							<h2 class="text-primary">Lucky Dice</h2> 
							</div><!--end .col -->
							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="genericstable3" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>ID</th>
												<th class="sort-alpha">Price</th>
												<th>Priority</th>
												<th>Start Date</th>
												<th>End Date</th>
												<th>Time Frame</th>
												<th>Profit</th>
												<th>Draw Type</th>
												<th>Status</th>
												<th>Created</th>
												<th>Action</th>
											</tr>
										</thead>
																			</table>
								</div><!--end .table-responsive -->
							</div><!--end .col -->
						</div><!--end .row -->	

				 <!-- END VERTICAL FORM -->               
				 </div>    
				 
				 </section>  
<!--Modal Box HTML for Creating New Category -->
  <div class="modal fade" id="genericsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Add Draw</h4>
      </div>
      <div class="modal-body">
      {!! Form::open(array('url'=>'admin/noform','method' => 'post','class'=>'form', 'files'=> true , 'id'=>'genericsform' )) !!}
        	<input type="hidden" name="catid" id="catid" value="">
            
			
			<div class="form-group floating-label">
                <input type="text" class="form-control" id="price" name="price">
                <label for="recipient-name">Draw Price:</label>
            </div>
			
			<div class="form-group floating-label">
                <?php /*?><input type="text" class="form-control" id="startdate" name="startdate"><?php */?>
				<input id="start-date" readonly autocomplete="off" type="text" name="startdate" class="form-control">
                <label for="recipient-name">Start Date:</label>
            </div>
			
			<div class="form-group floating-label">
                <?php /*?><input type="text" class="form-control" id="end-date" name="enddate"><?php */?>
				<input id="end-date" readonly autocomplete="off" type="text" name="enddate" class="form-control">
                <label for="recipient-name">End Date:</label>
            </div>
			
          <div class="form-group floating-label">
                            <label for="drawtoss">Draw Type </label>
									 
									 <select  class="form-control" id="type" name="type">
									  		<option value="">Select</option>
									        <option value="0">Draw</option>
									        <option value="1">Toss</option>
									         <option value="2">Lucky Dice</option>
                                       	
									  </select>
                                       </div>


			<div class="form-group floating-label hrs">
                <input type="number" class="form-control" id="timeframe1" name="hours" min="0" max="24" step="1">
                <label for="recipient-name">Hours:</label>
            </div>

			<div class="form-group floating-label mnt">
                <input type="number" class="form-control" id="timeframe2" name="minutes" min="1" max="59" step="1">
                <label for="recipient-name">Minutes:</label>
            </div>

            <div class="form-group floating-label">
                <input type="text" class="form-control" id="profit" name="profit">
                <label for="recipient-name">Profit:</label>
            </div>

            <div class="form-group floating-label">
                <input type="number"  class="form-control" id="priority" min="1"  name="priority">
                <label for="recipient-name">Priority:</label>
            </div>

             
			
            <input type="submit" id="genericsform_submit" name="genericsform_submit" style="display:none;">
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onClick="$('#genericsform_submit').click();">Save Draw</button>
      </div>
    </div>
  </div>
</div>
 </div>  <!--end #content-->
 <!-- END CONTENT -->

 </div>
<!--Modal Box HTML for Creating New Category -->
<script type="text/javascript">

$(document).ready(function(){

	window.setPriority = function(tableid){
		//console.log(tableid);
		$('#'+tableid+' .priority-update').blur(function(){
		  var catid = $(this).attr('data-category-id');
		  var priority = $(this).val();
		  $.ajax({
		      type: 'post',
		      url: '{{ URL::to("admin/updatepriorityajax")}}',
		      data: { "catid":catid, "priority": priority},
		      success: function(response){
		        //console.log('updated!');
		      }
		  });
		});
	}
	$(document).ajaxComplete(function(event, xhr, settings) {
		var the_url = settings.url.split('/');
		var the_url = the_url[the_url.length -1].split('?');
		console.log(the_url);
	    if (the_url[0] == "managedrawajax" ) {
			//console.log(the_url);
	    	window.setPriority('genericstable');
	    }
	    else if (the_url[0] == "managedrawajax2" ) {
	    	window.setPriority('genericstable2');
	    }
	    else if (the_url[0] == "managedrawajax3" ) {
	    	window.setPriority('genericstable3');
	    }
	});
    
    $("#type").change(function(){

        $(this).find("option:selected").each(function(){

            if($(this).attr("value")==0){

                $(".hrs").show();

                $(".mnt").show();

            }

            else if($(this).attr("value")==1){

                $(".hrs").hide();

                $(".mnt").hide();

            }

            else if($(this).attr("value")==2){

                 $(".hrs").hide();

                $(".mnt").hide();
            }

            else{

                //$(".box").hide();

            }

        });

    }).change();




    var genericstableajax = $('#genericstable').DataTable({
        "ajax": '{{ URL::to("admin/managedrawajax")}}',
        "ordering":  false
    });
	var genericstableajax2 = $('#genericstable2').DataTable({
        "ajax": '{{ URL::to("admin/managedrawajax2")}}',
        "ordering":  false
    });
	var genericstableajax3 = $('#genericstable3').DataTable({
        "ajax": '{{ URL::to("admin/managedrawajax3")}}',
        "ordering":  false
    });

    $.fn.dataTable.moment('MM/DD/YYYY');
		
 	$('#genericsform').bootstrapValidator({
		/*live:  'disabled',*/
		message: 'This value is not valid',
        fields: {
			type: {
                validators: {
                    notEmpty: {
                        message: 'Draw/Toss/Lucky Dice is required'
                    }
                }
            },
            price: {
                validators: {
				 	notEmpty: {
                        message: 'Price is required'
                    },
				  	regexp: {
                        regexp: /^\d{0,8}(\.\d{1,4})?$/,
                        message: 'Please enter a valid price'
                    },
                }
            },

            profit: {
                validators: {
				 	notEmpty: {
                        message: 'Profit is required'
                    },
				  	regexp: {
                        regexp: /^\d{0,8}(\.\d{1,4})?$/,
                        message: 'Please enter a valid profit'
                    },
                }
            },

           priority: {
                validators: {
				 	notEmpty: {
                        message: 'Priority is required'
                    },
				  	regexp: {
                        regexp: /^\+?(0*[1-9]\d*)$/,
                        message: 'Please enter a valid priority'
                    },
                     /*digits: {
							message: 'Enter only integer value'
						},*/
                }
            }, 
			
		 startdate: {
                validators: {
                    notEmpty: {
                        message: 'Start date is required'
                    }
                }
            },
			
			 enddate: {
                validators: {
                    notEmpty: {
                        message: 'End date is required'
                    }
                }
            },
			
			minutes: {
                validators: {
                    notEmpty: {
                        message: 'Time is required'
                    },
                    regexp: {
                        regexp: /^\+?(0*[1-9]\d*)$/,
                        message: 'Please enter a valid time'
                    },
                }
            },

            hours: {
                validators: {
                    notEmpty: {
                        message: 'Hours is required'
                    }
                }
            },
			
        },
		submitHandler: function(validator, form, submitButton) {
				var formdata = new FormData(form[0]);
				if($('#catid').val()=='')
				{
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/adddrawajax")}}',
							data: formdata,
							cache: false,
							contentType: false,
							processData: false,
							success: function(response)
							{
								if(response == 1)
								{
									$('#genericsModal').modal('hide');
									reloadcattable();
									var notyvar = noty({
									    text: 'Draw Added successfully',
									    type: 'success',
									    layout: 'bottomLeft',
									    theme:'defaultTheme'
									});
									setTimeout(function(){notyvar.close();},3000);
								}
								else
								{
									$('#cat_error').html(response);
								}
							}
						});
				}
				else
				{
					$.ajax({
						type: 'post',
						url: '{{ URL::to("admin/updatedrawajax")}}',
						data: formdata,
						cache: false,
						contentType: false,
						processData: false,
						success: function(response)
						{
							if(response == 1)
							{
								$('#genericsModal').modal('hide');
								reloadcattable();
								var notyvar2 = noty({
									    text: 'Draw Updated Successfully',
									    layout: 'bottomLeft',
									    theme:'defaultTheme',
									    type:'success'
									});
									setTimeout(function(){notyvar2.close();},4000);
							
							}
							else
							{
								$('#cat_error').html(response);
							}
							
						}
					});
				}
		 }
    });	

	  

	/*var nowTemp = new Date();
	var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

	var checkin = $('#start-date').datepicker({
		autoclose: true, 
		todayHighlight: true, 
		format: "yyyy-mm-dd",
		onRender: function(date) {
			return date.valueOf() < now.valueOf() ? 'disabled' : '';
		}
	}).on('changeDate', function (ev) {
        if (ev.date.valueOf() > checkout.date.valueOf()) {
		    var newDate = new Date(ev.date)
		    newDate.setDate(newDate.getDate() + 1);
		    checkout.setValue(newDate);
		}
		checkin.hide();
		$('#end-date')[0].focus();

		if($('#start-date').val()!=''){
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', false);
			$('#start-date').parent().parent().addClass('has-success');
		}
		else{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', true);
		}
    }).data('datepicker');;
		
	var checkout = $('#end-date').datepicker({
		autoclose: true,
		todayHighlight: true, 
		format: "yyyy-mm-dd",
		onRender: function(date) {
			return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
		}
	}).on('changeDate', function (ev) {
		checkout.hide();

		if($('#end-date').val()!=''){
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', false);
			$('#end-date').parent().parent().addClass('has-success');
		}
		else{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', true);
		}
 	}).data('datepicker');*/

 	/**/
	var startDate = new Date('01/01/2016');
	var FromEndDate = new Date();
	var ToEndDate = new Date();

	ToEndDate.setDate(ToEndDate.getDate()+365);

	$('#start-date').datepicker({

	    
	    startDate: FromEndDate,
	    autoclose: true
	})
	    .on('changeDate', function(selected){
	        startDate = new Date(selected.date.valueOf());
	        startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
	        $('#end-date').datepicker('setStartDate', new Date(new Date().setDate(startDate.getDate()+1)));

	        if($('#start-date').val()!=''){
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', false);
				$('#start-date').parent().parent().addClass('has-success');
			}
			else{
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', true);
			}
	    }); 
	$('#end-date')
	    .datepicker({

	        startDate: startDate,
	        endDate: ToEndDate,
	        autoclose: true
	    })
	    .on('changeDate', function(selected){
	        FromEndDate = new Date(selected.date.valueOf());
	        FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
	        $('#start-date').datepicker('setEndDate', FromEndDate);

	        if($('#end-date').val()!=''){
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', false);
				$('#end-date').parent().parent().addClass('has-success');
			}
			else{
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', true);
			}
	    });

});

function reloadcattable()
{
	$('#genericstable').DataTable().ajax.reload( null, false );
	$('#genericstable2').DataTable().ajax.reload( null, false );
	$('#genericstable3').DataTable().ajax.reload( null, false );
}

function open_addcatform()
{
	$('#genericsform').bootstrapValidator('resetForm', true);
	$('#catid').val('');
	$('#price').val('');
	$('#priority').val('');
	$('#start-date').val('');
	$('#end-date').val('');
	//$('#timeframe').val('');
	$('#timeframe1').val('');
	$('#timeframe2').val('');
	$('#profit').val('');
	$('#type').val('');
	$('#type').removeAttr('disabled');
	$('#genericsModal').modal('show');
		
}



function open_editcatform(catid)
{
	$('#genericsform').bootstrapValidator('resetForm', true);
	var securetoken = $("input[name=_token]").val();
	$.ajax({
			type: 'post',
			url: '{{ URL::to("admin/editdrawajax") }}',
			data: { "catid":catid,"_token" : securetoken},
			success: function(response)
			{ console.log(response);
				var obj = response; //jQuery.parseJSON(response);
				$('#catid').val(catid);
				$('#price').val(obj.price).addClass('dirty');
				$('#priority').val(obj.priority).addClass('dirty');
				$('#start-date').val(obj.startdate).addClass('dirty');
				$('#end-date').val(obj.enddate).addClass('dirty');
				$('#timeframe1').val(obj.hours).addClass('dirty');
				$('#timeframe2').val(obj.mins).addClass('dirty');
				$('#profit').val(obj.profit).addClass('dirty');
				$('#type').attr('disabled', 'disabled').val(obj.type).addClass('dirty');
				$('#type').trigger('change');
				//$('#type.readonly option:not(:selected)').attr('disabled',true);
				
			}
	});
	
	$('#genericsModal').modal('show');
	console.log('run');
		
}

function open_deletecatform(id,status)
{
	var securetoken = $("input[name=_token]").val();
	noty({
		text: 'Do you want to delete this Draw?',
		layout: 'center',
		template: '<div class="noty_message noty-title"><span class="noty_text"></span><div class="noty_close"></div></div>',
		buttons: [
			{addClass: 'btn btn-danger', text: 'Delete', onClick: function($noty) {
	
					// this = button element
					// $noty = $noty element
	
					$noty.close();
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/updatedrawstatus") }}',
							data: { "id":id, "status":status, "_token" : securetoken},
							success: function(response)
							{
								var notyvar = noty({text: 'Draw deleted successfully', type: 'success',layout: 'bottomLeft',theme:'defaultTheme'});
								reloadcattable();
								setTimeout(function(){notyvar.close();},3000);
							}
					});
					
				}
			},
			{addClass: 'btn btn-default', text: 'Cancel', onClick: function($noty) {
					$noty.close();
				}
			}
		]
	});	
}

function changecatstatus(id,status)
{
	var securetoken = $("input[name=_token]").val();
	noty({
		text: 'Do you want to change this Draw status?',
		layout: 'center',
		template: '<div class="noty_message noty-title"><span class="noty_text"></span><div class="noty_close"></div></div>',
		buttons: [
			{addClass: 'btn btn-danger', text: 'OK', onClick: function($noty) {
	
					// this = button element
					// $noty = $noty element
	
					$noty.close();
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/updatedrawstatus") }}',
							data: { "id":id, "status":status, "_token" : securetoken},
							success: function(response)
							{
								var notyvar = noty({text: 'Draw updated successfully', type: 'success',layout: 'bottomLeft',theme:'defaultTheme'});
								reloadcattable();
								setTimeout(function(){notyvar.close();},3000);
							}
					});
					
				}
			},
			{addClass: 'btn btn-default', text: 'Cancel', onClick: function($noty) {
					$noty.close();
				}
			}
		]
	});	
}
	
</script>


{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.tableTools.css') !!}
{!! HTML::script('resources/assets/backend/js/libs/bootstrap-datepicker/bootstrap-datepicker.js') !!}
{!! HTML::script('resources/assets/backend/js/noty/packaged/jquery.noty.packaged.min.js') !!}
{!! HTML::script('//cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.4/moment.min.js') !!}
{!! HTML::script('//cdn.datatables.net/plug-ins/1.10.11/sorting/datetime-moment.js') !!}
@stop
