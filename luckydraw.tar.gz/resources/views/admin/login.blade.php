<!DOCTYPE html>
<html lang="en">
	<head>
		<title>{{ config('constants.appName') }}</title>

		<!-- BEGIN META -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="your,keywords">
		<meta name="description" content="Short explanation about this website">
		<!-- END META -->

		<!-- BEGIN STYLESHEETS -->
		<link href='http://fonts.googleapis.com/css?family=Roboto:300italic,400italic,300,400,500,700,900' rel='stylesheet' type='text/css'/>
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/bootstrap.css?1422792965" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/materialadmin.css?1425466319" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/font-awesome.min.css?1422529194" />
		<link type="text/css" rel="stylesheet" href="{{ Request::root() }}/resources/assets/backend/css/theme-default/material-design-iconic-font.min.css?1421434286" />
		<!-- END STYLESHEETS -->

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script type="text/javascript" src="assets/js/libs/utils/html5shiv.js?1403934957"></script>
		<script type="text/javascript" src="assets/js/libs/utils/respond.min.js?1403934956"></script>
		<![endif]-->
		<script src="{{ Request::root() }}/resources/assets/backend/js/libs/jquery/jquery-1.11.2.min.js"></script>
	</head>
	<body class="menubar-hoverable header-fixed ">

		<!-- BEGIN LOGIN SECTION -->
		<div class="section-account">
            <div class="card-body no-padding">
                <div class="alert alert-callout alert-info no-margin">
                    <h1 class="wlmsg text-center">{{ config('constants.appName') }}</h1>
                </div>
            </div>
			<div class="img-backdrop" style="background-image: url('assets/img/img16.jpg')"></div>
			<!--<div class="spacer"></div>-->
			<div class="card contain-sm style-transparent">
				<div class="card-body">
					<div class="row">
                        @if(Session::has('message'))
                            <p class="alert alert-info">{{ Session::get('message') }}</p>
                        @endif

                        @if($errors->has())
                            <p class="alert alert-info">
                                @foreach ($errors->all() as $error)
                                    {{ $error }}<br />
                                @endforeach
                            </p>
                        @endif
                        <div class="col-sm-12">
                            <span class="text-lg text-bold text-primary">Admin Login</span>
                            <br/><br/>
                            {!! Form::open(array('url'=>'admin/postlogin', 'class'=>'form floating-label' , 'id' => 'loginform')) !!}
                                <div class="form-group">
                                    <input type="text" class="form-control" id="email" name="email">
                                    <label for="email">Username</label>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="password" name="password">
                                    <label for="password">Password</label>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-6 text-left">
                                        <div class="checkbox checkbox-inline checkbox-styled">
                                            <label>
                                                <input type="checkbox"> <span>Remember Me</span>
                                            </label>
                                        </div>
                                    </div><!--end .col -->
                                    <div class="col-xs-6 text-right">
                                        <button class="btn btn-primary btn-raised" type="submit">Login</button>
                                    </div><!--end .col -->
                                </div><!--end .row -->
                            </form>
                        </div><!--end .col -->
                    </div><!--end .row -->
                </div><!--end .card-body -->
            </div><!--end .card -->
        </div>
        <!-- END LOGIN SECTION -->

        <!-- BEGIN JAVASCRIPT -->
        <script src="{{ Request::root() }}/resources/assets/backend/js/libs/jquery/jquery-migrate-1.2.1.min.js"></script>
        <script src="{{ Request::root() }}/resources/assets/backend/js/libs/bootstrap/bootstrap.min.js"></script>
        {!! HTML::script('/resources/assets/backend/js/bootstrapValidator.min.js') !!}
        <!-- END JAVASCRIPT -->
		<script type="text/javascript">
            $(document).ready(function() {
                $('#loginform').bootstrapValidator({
                    message: "This value is not valid",
                    fields: {
                        email: {
                            validators: {
                                notEmpty: {
                                    message: "Username is required"
                                }
                            }
                        },
                        password: {
                            validators: {
                                notEmpty: {
                                    message: "Password is required"
                                }
                            }
                        }
                    }
                });
            });
        </script>
    </body>
</html>
