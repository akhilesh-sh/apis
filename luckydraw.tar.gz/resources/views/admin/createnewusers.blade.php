@extends('adminlayout')
@section('content')
 
<style>
h1{ margin-left: 20px;
   margin-top:20px;
}
</style>
 

    <div class="section-body contain-lg">

						<!-- BEGIN VERTICAL FORM -->
						<div class="row">
							<div class="col-lg-12">
								<h1 class="text-primary">Create New User</h1>
							</div><!--end .col -->
							<div class="col-lg-3 col-md-4">
								<article class="margin-bottom-xxl">
									@if(Session::has('message'))
							 <p class="alert alert-info">{{ Session::get('message') }}</p>
						@endif
						@if($errors->has())
							@foreach ($errors->all() as $error)
							 	<p class="lead text-danger">{{ $error }}</p>
							@endforeach
						@endif
								</article>
							</div><!--end .col -->
							<div class="col-lg-offset-1 col-md-8">
					<form id="createuserform" class="form" enctype="multipart/form-data" accept-charset="UTF-8" action="{{ Request::root() }}/admin/createnewusers" method="POST">
								
									<div class="card">
										<div class="card-head style-primary">
											<header>Enter New User Details</header>
										</div>
										<div class="card-body">
										<div id="message">
										<font color="red"></font> 
										<font color="green"></font>
										</div>
										<h2>Users Details</h2>
											<div class="form-group">
												<input type="text" value="" name="email" id="email"  class="form-control">
												<input type="hidden" value="false" name="emailvalid" id="emailvalid">
												{{ csrf_field() }}
												<label for="institutename">Email &nbsp; <span class="error_username" style="color:red;"></span></label>
											</div>
											<div class="form-group">
												<input type="password" value="" name="password" id="password"  class="form-control">
												<label for="password">Password</label>
											</div>
											
											<div class="form-group">
												<input type="password" value="" name="cpassword"  id="cpassword"  class="form-control">
												<label for="cpassword">Confirm Password</label>
											</div>
											
											<div class="form-group">
												<input type="text" value="" name="name" id="name"  class="form-control">
												<label for="fname">First Name</label>
											</div>
											
											
											<div class="form-group">
												<input type="text" value="" name="last_name" id="last_name"  class="form-control">
												<label for="lname">Last Name</label>
											</div>
											
											<div class="form-group">
												<input type="text" value="" name="phone" id="phone"  class="form-control">
												<label for="lname">Phone</label>
											</div>
											
                                            
										</div><!--end .card-body -->
										<div class="card-actionbar">
											<div class="card-actionbar-row">
												<button class="btn btn-flat btn-primary ink-reaction" type="submit">Create User</button>
											</div>
										</div>
									</div><!--end .card -->
									<em class="text-caption">Create new user on click "Create User"</em>
								</form>
							</div><!--end .col -->
						</div><!--end .row -->
						<!-- END VERTICAL FORM -->
					</div>
<script type="text/javascript">
$(document).ready(function() {
   <?php /*?> document.getElementById("uploadBtn").onchange = function () {
		readURL(this,'profilePic');
	};<?php */?>
	
		
 	$('#createuserform').bootstrapValidator({
		//live:  'disabled',
		message: 'This value is not valid',
        fields: {
			image: {
                validators: {
                    notEmpty: {
                        message: 'Image is required'
                    }
                }
            },
			
			email: {
                validators: {
				 	notEmpty: {
						message: 'Email is required'
					},
					emailAddress: {
                        message: 'Email address is not valid'
                    },
					 remote: {
                        message:'Email already exist with the given email',
                        url: '{{ URL::to("admin/checkexisringuser")}}',
						data: function(validator, $field, value) {
                            return {
                                email: validator.getFieldElements('email').val()
                            };
                        },
                        type: 'POST'
                    }
                }
            },
			
			password: {
                validators: {
					notEmpty: {
						message: 'Password is required'
					}
                }
            },
			
			cpassword: {
                validators: {
					notEmpty: {
						message: 'The password and its confirm are not same'
					},
                    identical: {
                        field: 'password',
                        message: 'The password and its confirm are not same'
                    }
                }
            },
			
			name: {
                validators: {
                    notEmpty: {
                        message: 'First name is required'
                    }
                }
            },
			
			phone: {
                  validators: {
					   digits: {
						message: 'Please provide a valid phone number'
					}
                }
            },
			
			 last_name: {
                validators: {
                    notEmpty: {
                        message: 'Last name is required'
                    }
                }
            },
			
		

			<?php /*?>iemail: {
                validators: {
                    notEmpty: {
                        message: 'Email address is required'
                    },
					emailAddress: {
                        message: 'Email address is not valid'
                    }
                }
            },<?php */?>
			
		
		}
    });

} );
</script>
<!--Modal Box HTML for Creating New Category -->
{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
<?php /*?>{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js') !!}<?php */?>

@stop