@extends('adminlayout')
@section('content')
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.tableTools.css') !!}
<style type="text/css">
.margin-bottom-xxl{margin-left:10px;}
.section-body:first-child {
    margin-top: 0px !important;
}
</style>
<div id="content">    
				<section class="style-default-bright">
				<div class="section-body contain-lg">
				 <!-- BEGIN VERTICAL FORM -->
				 <div class="row">          
				 <div class="col-lg-12">
                	<div class="col-sm-10 pull-left">
                    	<h1 class="text-primary">Manage FAQ</h1>
                    </div>
				 	
                    <div class="col-sm-2 pull-right">
                    	<button style="margin-top:24px;" onclick="open_addcatform()" class="btn btn-block ink-reaction btn-primary">Add FAQ</button>
                    </div>
				 </div>          <!--end .col -->
				 <div class="col-lg-12 col-md-12">
				<article class="margin-bottom-xxl">
					<ul>
						<li>Edit, view or delete Draw data.</li>
					</ul>
				 </article>
				 </div>
				 <!--end .col -->
				 <div  id="message">
				@if(Session::has('message'))
							 <p class="alert alert-info">{{ Session::get('message') }}</p>
						@endif
						@if($errors->has())
							@foreach ($errors->all() as $error)
							 	<p class="lead text-danger">{{ $error }}</p>
							@endforeach
						@endif
				 </div>          
				 
				 <!-- BEGIN TABLE HOVER -->				
				 </div>        
				 
				 <!--end .row -->
						<div class="row">
							<div class="col-md-12">
							<h2 class="text-primary">FAQ List</h2> 
							</div><!--end .col -->
							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="genericstable" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>ID</th>
												<th>Questions</th>
												<th>Answer</th>
												<th>Status</th>
												<th>Created</th>
												<th>Action</th>
											</tr>
										</thead>
																			</table>
								</div><!--end .table-responsive -->
							</div><!--end .col -->
						</div><!--end .row -->				 
				 
				 <!-- END VERTICAL FORM -->               
				 </div>    
				 
				 </section>  
<!--Modal Box HTML for Creating New Category -->
  <div class="modal fade" id="genericsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Add FAQ</h4>
      </div>
      <div class="modal-body">
      {!! Form::open(array('url'=>'admin/noform','method' => 'post','class'=>'form', 'files'=> true , 'id'=>'genericsform' )) !!}
        	<input type="hidden" name="catid" id="catid" value="">
            
			
			<div class="form-group floating-label">
                <input type="text" class="form-control" id="title" name="title">
                <label for="recipient-name">Question</label>
            </div>

            <div class="form-group floating-label">
                <input type="text" class="form-control" id="description" name="description">
                <label for="recipient-name">Answer:</label>
            </div>    
			
            <input type="submit" id="genericsform_submit" name="genericsform_submit" style="display:none;">
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onClick="$('#genericsform_submit').click();">Save FAQ</button>
      </div>
    </div>
  </div>
</div>
 </div>  <!--end #content-->
 <!-- END CONTENT -->

 </div>
<!--Modal Box HTML for Creating New Category -->
<script type="text/javascript">
$(document).ready(function() {
    var genericstableajax = $('#genericstable').DataTable({
        "ajax": '{{ URL::to("admin/faqajax")}}'
    });

    $.fn.dataTable.moment('MM/DD/YYYY');
		
 	$('#genericsform').bootstrapValidator({
		/*live:  'disabled',*/
		message: 'This value is not valid',
        fields: {
			type: {
                validators: {
                    notEmpty: {
                        message: 'Draw/Toss is required'
                    }
                }
            },

            title: {
                validators: {
				 	notEmpty: {
                        message: 'Question is required'
                    },
                }
            },
			
		 description: {
                validators: {
                    notEmpty: {
                        message: 'Answer is required'
                    }
                }
            },
			

            hours: {
                validators: {
                    notEmpty: {
                        message: 'Hours is required'
                    }
                }
            },
			
        },
		submitHandler: function(validator, form, submitButton) {
				var formdata = new FormData(form[0]);
				if($('#catid').val()=='')
				{
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/addfaqajax")}}',
							data: formdata,
							cache: false,
							contentType: false,
							processData: false,
							success: function(response)
							{
								if(response == 1)
								{
									$('#genericsModal').modal('hide');
									reloadcattable();
									var notyvar = noty({
									    text: 'FAQ Added successfully',
									    type: 'success',
									    layout: 'bottomLeft',
									    theme:'defaultTheme'
									});
									setTimeout(function(){notyvar.close();},3000);
								}
								else
								{
									$('#cat_error').html(response);
								}
							}
						});
				}
				else
				{
					$.ajax({
						type: 'post',
						url: '{{ URL::to("admin/updatedfaqajax")}}',
						data: formdata,
						cache: false,
						contentType: false,
						processData: false,
						success: function(response)
						{
							if(response == 1)
							{
								$('#genericsModal').modal('hide');
								reloadcattable();
								var notyvar2 = noty({
									    text: 'FAQ Updated Successfully',
									    layout: 'bottomLeft',
									    theme:'defaultTheme',
									    type:'success'
									});
									setTimeout(function(){notyvar2.close();},4000);
							
							}
							else
							{
								$('#cat_error').html(response);
							}
							
						}
					});
				}
		 }
    });	
	/*var nowTemp = new Date();
	var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

	var checkin = $('#start-date').datepicker({
		autoclose: true, 
		todayHighlight: true, 
		format: "yyyy-mm-dd",
		onRender: function(date) {
			return date.valueOf() < now.valueOf() ? 'disabled' : '';
		}
	}).on('changeDate', function (ev) {
        if (ev.date.valueOf() > checkout.date.valueOf()) {
		    var newDate = new Date(ev.date)
		    newDate.setDate(newDate.getDate() + 1);
		    checkout.setValue(newDate);
		}
		checkin.hide();
		$('#end-date')[0].focus();

		if($('#start-date').val()!=''){
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', false);
			$('#start-date').parent().parent().addClass('has-success');
		}
		else{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', true);
		}
    }).data('datepicker');;
		
	var checkout = $('#end-date').datepicker({
		autoclose: true,
		todayHighlight: true, 
		format: "yyyy-mm-dd",
		onRender: function(date) {
			return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
		}
	}).on('changeDate', function (ev) {
		checkout.hide();

		if($('#end-date').val()!=''){
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', false);
			$('#end-date').parent().parent().addClass('has-success');
		}
		else{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', true);
		}
 	}).data('datepicker');*/

 	/**/
	var startDate = new Date('01/01/2016');
	var FromEndDate = new Date();
	var ToEndDate = new Date();

	ToEndDate.setDate(ToEndDate.getDate()+365);

	$('#start-date').datepicker({

	    
	    startDate: FromEndDate,
	    autoclose: true
	})
	    .on('changeDate', function(selected){
	        startDate = new Date(selected.date.valueOf());
	        startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
	        $('#end-date').datepicker('setStartDate', new Date(new Date().setDate(startDate.getDate()+1)));

	        if($('#start-date').val()!=''){
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', false);
				$('#start-date').parent().parent().addClass('has-success');
			}
			else{
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', true);
			}
	    }); 
	$('#end-date')
	    .datepicker({

	        startDate: startDate,
	        endDate: ToEndDate,
	        autoclose: true
	    })
	    .on('changeDate', function(selected){
	        FromEndDate = new Date(selected.date.valueOf());
	        FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
	        $('#start-date').datepicker('setEndDate', FromEndDate);

	        if($('#end-date').val()!=''){
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', false);
				$('#end-date').parent().parent().addClass('has-success');
			}
			else{
				$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', true);
			}
	    });

});

function reloadcattable()
{
	$('#genericstable').DataTable().ajax.reload( null, false );
}

function open_addcatform()
{
	$('#genericsform').bootstrapValidator('resetForm', true);
	$('#catid').val('');
	$('#title').val('');
	$('#description').val('');
	$('#genericsModal').modal('show');
		
}



function open_editcatform(catid)
{
	$('#genericsform').bootstrapValidator('resetForm', true);
	var securetoken = $("input[name=_token]").val();
	$.ajax({
			type: 'post',
			url: '{{ URL::to("admin/editfaqajax") }}',
			data: { "catid":catid,"_token" : securetoken},
			success: function(response)
			{ console.log(response);
				var obj = response; //jQuery.parseJSON(response);
				$('#catid').val(catid);
				$('#title').val(obj.title).addClass('dirty');
				$('#description').val(obj.description).addClass('dirty');
				
				
			}
	});
	
	$('#genericsModal').modal('show');
		
}

function open_deletecatform(id,status)
{
	var securetoken = $("input[name=_token]").val();
	noty({
		text: 'Do you want to delete this Draw?',
		layout: 'center',
		template: '<div class="noty_message noty-title"><span class="noty_text"></span><div class="noty_close"></div></div>',
		buttons: [
			{addClass: 'btn btn-danger', text: 'Delete', onClick: function($noty) {
	
					// this = button element
					// $noty = $noty element
	
					$noty.close();
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/updatedfaqstatus") }}',
							data: { "id":id, "status":status, "_token" : securetoken},
							success: function(response)
							{
								var notyvar = noty({text: 'FAQ deleted successfully', type: 'success',layout: 'bottomLeft',theme:'defaultTheme'});
								reloadcattable();
								setTimeout(function(){notyvar.close();},3000);
							}
					});
					
				}
			},
			{addClass: 'btn btn-default', text: 'Cancel', onClick: function($noty) {
					$noty.close();
				}
			}
		]
	});	
}

function changecatstatus(id,status)
{
	var securetoken = $("input[name=_token]").val();
	noty({
		text: 'Do you want to change this Draw status?',
		layout: 'center',
		template: '<div class="noty_message noty-title"><span class="noty_text"></span><div class="noty_close"></div></div>',
		buttons: [
			{addClass: 'btn btn-danger', text: 'OK', onClick: function($noty) {
	
					// this = button element
					// $noty = $noty element
	
					$noty.close();
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/updatedfaqstatus") }}',
							data: { "id":id, "status":status, "_token" : securetoken},
							success: function(response)
							{
								var notyvar = noty({text: 'FAQ updated successfully', type: 'success',layout: 'bottomLeft',theme:'defaultTheme'});
								reloadcattable();
								setTimeout(function(){notyvar.close();},3000);
							}
					});
					
				}
			},
			{addClass: 'btn btn-default', text: 'Cancel', onClick: function($noty) {
					$noty.close();
				}
			}
		]
	});	
}
	
</script>


{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.tableTools.css') !!}
{!! HTML::script('resources/assets/backend/js/libs/bootstrap-datepicker/bootstrap-datepicker.js') !!}
{!! HTML::script('resources/assets/backend/js/noty/packaged/jquery.noty.packaged.min.js') !!}
{!! HTML::script('//cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.4/moment.min.js') !!}
{!! HTML::script('//cdn.datatables.net/plug-ins/1.10.11/sorting/datetime-moment.js') !!}
@stop
