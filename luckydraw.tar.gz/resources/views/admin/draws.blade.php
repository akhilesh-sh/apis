@extends('adminlayout')
@section('content')
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/jquery.dataTables.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.colVis.css') !!}
{!! HTML::style('resources/assets/backend/css/theme-default/libs/DataTables/extensions/dataTables.tableTools.css') !!}
<style type="text/css">
.margin-bottom-xxl{margin-left:10px;}
.section-body:first-child {
    margin-top: 0px !important;
}
</style>
<div id="content">    
				<section class="style-default-bright">
				<div class="section-body contain-lg">
				 <!-- BEGIN VERTICAL FORM -->
				 <div class="row">          
				 <div class="col-lg-12">
                	<div class="col-sm-10 pull-left">
                    	<h1 class="text-primary">Active Draws</h1>
                    </div>
				 
				 </div>          <!--end .col -->
				 <div class="col-lg-12 col-md-12">
				<article class="margin-bottom-xxl">
					<ul>
						<!-- <li>Edit, view or delete Draws data.</li> -->
					</ul>
				 </article>
				 </div>
				 <!--end .col -->
				 <div  id="message">
				@if(Session::has('message'))
							 <p class="alert alert-info">{{ Session::get('message') }}</p>
						@endif
						@if($errors->has())
							@foreach ($errors->all() as $error)
							 	<p class="lead text-danger">{{ $error }}</p>
							@endforeach
						@endif
				 </div>          
				 
				 <!-- BEGIN TABLE HOVER -->				
				 </div>        
				 
				 <!--end .row -->
						<div class="row">
							<div class="col-md-12">
							<h2 class="text-primary">Draws List</h2> 
							</div><!--end .col -->
							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="genericstable" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>ID</th>
												<th class="sort-alpha">Draw ID</th>
												<th>Draw Type</th>
												<th>Total Amount</th>
												<th>Profit</th>
												<th>Winning Amount</th>
												<th>Participants</th>
												<!-- <th>Wnner ID</th>
												<th>Status</th> -->
												<th>Created</th>
												<!-- <th>Action</th> -->
											</tr>
										</thead>
																			</table>
								</div><!--end .table-responsive -->
							</div><!--end .col -->
						</div><!--end .row -->				 
				 
				 <!-- END VERTICAL FORM -->               
				 </div>    
				 
				 </section>
				  </div>

<!--Modal Box HTML for Creating New Category -->
<script type="text/javascript">
$(document).ready(function() {
    var genericstableajax = $('#genericstable').DataTable({
        "ajax": '{{ URL::to("admin/drawsajax")}}'
    } );
		
 	$('#genericsform').bootstrapValidator({
		live:  'disabled',
		message: 'This value is not valid',
        fields: {
			type: {
                validators: {
                    notEmpty: {
                        message: 'Save Draw'
                    }
                }
            },
            price: {
                validators: {
				 notEmpty: {
                        message: 'Price is required'
                    },
				  regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The price can only consist of numbers'
                    },      
                }
            },
			
	
			
			timeframe: {
                validators: {
                    notEmpty: {
                        message: 'Time is required'
                    }
                }
            },
			
        },
		submitHandler: function(validator, form, submitButton) {
				var formdata = new FormData(form[0]);
				if($('#catid').val()=='')
				{
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/adddrawajax")}}',
							data: formdata,
							cache: false,
							contentType: false,
							processData: false,
							success: function(response)
							{
								if(response == 1)
								{
									$('#genericsModal').modal('hide');
									reloadcattable();
									var notyvar = noty({
										text: 'Draw Added Successfully',
										layout: 'bottomRight',
										timeout:300,
										animation: {
											open: 'animated bounceInLeft', // Animate.css class names
											close: 'animated bounceOutLeft', // Animate.css class names
										}
									});
								}
								else
								{
									$('#cat_error').html(response);
								}
							}
						});
				}
				else
				{
					$.ajax({
						type: 'post',
						url: '{{ URL::to("admin/updatedrawajax")}}',
						data: formdata,
						cache: false,
						contentType: false,
						processData: false,
						success: function(response)
						{
							if(response == 1)
							{
								$('#genericsModal').modal('hide');
								reloadcattable();
								var notyvar = noty({
										text: 'Draw Updated Successfully',
										layout: 'bottomLeft',
										theme:'defaultTheme',
										timeout:true,
										type:'success',
										animation: {
											open: 'animated fadeIn', // Animate.css class names
											close: 'animated fadeOut', // Animate.css class names
										}
									});
								setTimeout(function(){notyvar.close();},3000);
							}
							else
							{
								$('#cat_error').html(response);
							}
							
						}
					});
				}
		 }
    });	
	
	$('#start-date').datepicker({autoclose: true, todayHighlight: true, format: "yyyy-mm-dd"}).on('changeDate', function (ev) {
		if($('#start-date').val()!='')
		{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', false);
			$('#start-date').parent().parent().addClass('has-success');
		}
		else
		{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('startdate', true);
		}
	});
		
	  $('#end-date').datepicker({autoclose: true, todayHighlight: true, format: "yyyy-mm-dd"}).on('changeDate', function (ev) {
		if($('#end-date').val()!='')
		{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', false);
			$('#end-date').parent().parent().addClass('has-success');
		}
		else
		{
			$('#genericsform').data('bootstrapValidator').enableFieldValidators('enddate', true);
		}
	});
	
	
} );	

function reloadcattable()
{
	$('#genericstable').DataTable().ajax.reload( null, false );
}



function changecatstatus(id,status)
{
	var securetoken = $("input[name=_token]").val();
	noty({
		text: 'Do you want to change this Draw status?',
		layout: 'center',
		template: '<div class="noty_message noty-title"><span class="noty_text"></span><div class="noty_close"></div></div>',
		buttons: [
			{addClass: 'btn btn-danger', text: 'OK', onClick: function($noty) {
	
					// this = button element
					// $noty = $noty element
	
					$noty.close();
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/updateddrawsstatus") }}',
							data: { "id":id, "status":status, "_token" : securetoken},
							success: function(response)
							{
								var notyvar = noty({text: 'Draws updated successfully', type: 'success',layout: 'bottomLeft',theme:'defaultTheme'});
								reloadcattable();
								setTimeout(function(){notyvar.close();},3000);
							}
					});
					
				}
			},
			{addClass: 'btn btn-default', text: 'Cancel', onClick: function($noty) {
					$noty.close();
				}
			}
		]
	});	
}
	
</script>

{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/noty/packaged/jquery.noty.packaged.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/bootstrap-datepicker/bootstrap-datepicker.js') !!}
@stop