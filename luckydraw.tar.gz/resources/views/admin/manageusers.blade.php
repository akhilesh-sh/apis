@extends('adminlayout')
@section('content')
 
<style>
h1{ margin-left: 20px;}
.createuserbtn{ margin:5px;}
</style>
 

    <section>
        <div class="section-body">
            <div class="row">
                <div class="col-sm-8 pull-left">
                    <h1 class="nomargin text-primary">Manage users</h1>
                </div>
				
				<!-- <div class="col-sm-4 pull-left">
                    <a href="{{ Request::root() }}/admin/createnewusers"><input type="button" value="Create New Users" class="btn btn-primary pull-right createuserbtn" /></a>
                </div>!-->
				 
				
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table id="userstable" class="table order-column hover" data-source="data/users.json" data-swftools="{{ Request::root() }}/resources/assets/backend/js/libs/DataTables/extensions/TableTools/swf/copy_csv_xls.swf">
                            <thead>
                                <tr>
												<th>ID</th>
												<th class="sort-alpha">Email</th>
												<th>First Name </th>
												<th>Last Name</th>
												<th>Username</th>
												<th class="sort-numeric">Phone</th>
												<th>Balance</th>
												<th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div><!--end .table-responsive -->
                </div>
            </div><!--end .row -->
        
        </div><!--end .section-body -->
    </section>

<script type="text/javascript">
$(document).ready(function() {
	
    $('#userstable').DataTable({
		"initComplete": function () {
           $('.image-popup-no-margins').magnificPopup({
				type: 'image',
				closeOnContentClick: true,
				closeBtnInside: false,
				fixedContentPos: true,
				mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
				image: {
					verticalFit: true
				},
				zoom: {
					enabled: true,
					duration: 300 // don't foget to change the duration also in CSS
				}
			});
        },
		"ajax": '{{ URL::to("admin/manageusersajax")}}',
		"dom": 'TlCfrtip',
		"colVis": {
			"buttonText": "Columns",
			"overlayFade": 0,
			"align": "right"
		},
		"tableTools": {
			"sSwfPath": $('#userstable').data('swftools'),
			"aButtons": [
				{
					"sExtends": "copy",
					"sButtonText": "Copy",
					"oSelectorOpts": {
						page: 'current'
					}
				},
				{
					"sExtends": "csv",
					"sButtonText": "CSV",
					"oSelectorOpts": {
						page: 'current'
					}
				},
				{
					"sExtends": "xls",
					"sButtonText": "XLS",
					"sFileName": "*.xls",
					"oSelectorOpts": {
						page: 'current'
					}
				}
			]
		},
		"order": [[1, 'asc']],
		"language": {
			"lengthMenu": '_MENU_ entries per page',
			"search": '<i class="fa fa-search"></i>',
			"paginate": {
				"previous": '<i class="fa fa-angle-left"></i>',
				"next": '<i class="fa fa-angle-right"></i>'
			}
		}
	});
	
} );	

function reloadcattable()
{
	$('#userstable').DataTable().ajax.reload( null, false );
}

function changeuserstatus(id,status)
{
	var securetoken = $("input[name=_token]").val();
	noty({
		text: 'Do you want to change this user status?',
		layout: 'center',
		template: '<div class="noty_message noty-title"><span class="noty_text"></span><div class="noty_close"></div></div>',
		buttons: [
			{addClass: 'btn btn-danger', text: 'OK', onClick: function($noty) {
	
					// this = button element
					// $noty = $noty element
	
					$noty.close();
					$.ajax({
							type: 'post',
							url: '{{ URL::to("admin/updateusersstatus") }}',
							data: { "id":id, "status":status, "_token" : securetoken},
							success: function(response)
							{
								var notyvar = noty({text: 'User updated successfully', type: 'success',layout: 'bottomLeft',theme:'defaultTheme'});
								reloadcattable();
								setTimeout(function(){notyvar.close();},3000);
							}
					});
					
				}
			},
			{addClass: 'btn btn-default', text: 'Cancel', onClick: function($noty) {
					$noty.close();
				}
			}
		]
	});	
}
	

</script>
<!--Modal Box HTML for Creating New Category -->
{!! HTML::script('resources/assets/backend/js/noty/packaged/jquery.noty.packaged.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js') !!}

@stop