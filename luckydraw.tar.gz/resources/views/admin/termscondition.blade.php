@extends('adminlayout')
@section('content')

<style>
	.section-body{
	margin-left: 50px;
	margin-right:50px;
	}
.card .form-group{ margin:20px;}
.cke_button_icon.cke_button__image_icon {
    display: none !important;
}	
	
</style>		
						

<section>
		<div class="section-body">
			<div class="row">
                <div class="col-sm-10 pull-left">
                    <h3 class="nomargin text-primary">Terms & Conditions</h3>
                </div>
            </div>
            <hr>
			<!-- BEGIN VERTICAL FORM -->
			<div class="row">
				<div class="col-lg-12">
					<article class="margin-bottom-xxl">
						@if(Session::has('message'))
							 <p class="alert alert-info">{{ Session::get('message') }}</p>
						@endif
						@if($errors->has())
							@foreach ($errors->all() as $error)
							 	<p class="lead text-danger">{{ $error }}</p>
							@endforeach
						@endif
					</article>
				</div><!--end .col -->
				
				<div class="col-lg-12">
					{{	Form::open(array('route'=>'termscondtion','id'=>'termsform'))}}

						<div class="card">
							<div class="card-head style-primary">
								<header>Terms & Conditions</header>
							</div>
                            
                            
                    
	           				<div style="clear:both;"></div>
			
                             <div class="form-group floating-label">
                                {{ Form::label('title','Title')}}
                                {{ Form::text('title',$title,array('class'=>'form-control')) }}
                                
                             </div>

                             <div class="form-group floating-label">
                             	{{ Form::label('description','Description')}}
                                <textarea id="description" class="form-control" name="description">{!! $description !!}</textarea>
                        	</div>
							 
							<div class="form-group">
								<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button class="btn btn-primary" type="submit">SAVE</button>
								</div>
                                </div>
							</div>
							
						</div><!--end .card-body -->
                        </form>
                    </div>
                </div><!--end .card -->
        
        </div><!--end .col -->
        
</section>
{{ HTML::script('//cdn.ckeditor.com/4.5.4/full/ckeditor.js') }}
<script type="text/javascript">

$(document).ready(function() {

  	CKEDITOR.replace('description', {
		filebrowserUploadUrl: '{{ Request::root() }}/admin/terms'
	});
	
	CKEDITOR.config.removePlugins = 'save,preview,forms,flash,iframe,about';

 	$('#termsform').bootstrapValidator({
		//live:  'disabled',
		message: 'This value is not valid',
        fields: {
			title: {
	            validators: {
	                notEmpty: {
	                    message: 'Title is required'
	                }
	            }
	        },
			description: {
	            validators: {
	                notEmpty: {
	                    message: 'Description is required'
	                }
	            }
	        },
		}
    });	
});	
	
</script>

{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js') !!}

@stop