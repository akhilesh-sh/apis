@extends('adminlayout')
@section('content')

<style>
	.section-body{
	margin-left: 50px;
	margin-right:50px;
	}
.card .form-group{ margin:20px;}	
	
</style>		
						

<section>
		<div class="section-body">
			<div class="row">
                <div class="col-sm-10 pull-left">
                    <h3 class="nomargin text-primary">Manage Sharing</h3>
                </div>
            </div>
            <hr>
			<!-- BEGIN VERTICAL FORM -->
			<div class="row">
				<div class="col-lg-12">
					<article class="margin-bottom-xxl">
						@if(Session::has('message'))
							 <p class="alert alert-info">{{ Session::get('message') }}</p>
						@endif
						@if($errors->has())
							@foreach ($errors->all() as $error)
							 	<p class="lead text-danger">{{ $error }}</p>
							@endforeach
						@endif
					</article>
				</div><!--end .col -->
				
				<div class="col-lg-12">
					<form id="profileform" class="form" enctype="multipart/form-data" accept-charset="UTF-8" action="{{ Request::root() }}/admin/manageshare" method="POST">
						<div class="card">
							<div class="card-head style-primary">
								<header>Manage Sharing</header>
							</div>
                            
                            
                    
	           <div style="clear:both;"></div>
			
			                 <div class="form-group floating-label">
							 <img style="width:150px; height:150px;" src="{{ Request::root() }}/resources/assets/uploads/{{ $Userinfo->image }}" >
                                <input type="file" class="form-control" name="image" value="">
                             </div>
			                 
							 
                             <div class="form-group floating-label">
                                <input type="text" class="form-control" name="title" value="{{ $Userinfo->title}}">
								<label>Tttle</label>
                             </div>

                             <div class="form-group floating-label">
                              <textarea class="form-control" name="description">{{ $Userinfo->description}}</textarea>
                            <label>Description</label>
                        </div>
							 
							<div class="form-group">
								<div class="card-actionbar">
								<div class="card-actionbar-row">
									<button class="btn btn-primary" type="submit">SAVE</button>
								</div>
                                </div>
							</div>
							
						</div><!--end .card-body -->
                        </form>
                    </div>
                </div><!--end .card -->
        
        </div><!--end .col -->
        
</section>

	<script type="text/javascript">
$(document).ready(function() {
 	$('#profileform').bootstrapValidator({
		//live:  'disabled',
		message: 'This value is not valid',
        fields: {
		 title: {
                validators: {
                    notEmpty: {
                        message: 'Title is required'
                    }
                }
            },
			
			description: {
                validators: {
                    notEmpty: {
                        message: 'Description is required'
                    }
                }
            },
			
		}
    });	
} );	

	
</script>

{!! HTML::script('resources/assets/backend/js/bootstrapValidator.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/jquery.dataTables.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/ColVis/js/dataTables.colVis.min.js') !!}
{!! HTML::script('resources/assets/backend/js/libs/DataTables/extensions/TableTools/js/dataTables.tableTools.min.js') !!}

@stop