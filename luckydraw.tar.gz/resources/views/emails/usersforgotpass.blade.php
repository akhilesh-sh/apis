<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"/>
    	<title>LuckyDraw App</title>
    </head>
    <body bgcolor="#f0eee7" style="background: #f0eee7;">
        <table cellpadding="0" bgcolor="#fff" cellspacing="0" border="0" width="700px" style="width: 700px; margin: 0 auto; background: #fff; border: 1px solid #e8e8e8; border-radius: 5px; overflow: hidden;">
            <tr>
                <td align="center" bgcolor="#fff" style="padding: 30px 0; background: #fff;  border-radius: 5px;">
                <h1 style="font-family: arial; color: #333; font-size: 30px; text-transform: uppercase; padding: 0 0 10px;">Reset Password</h1>
                <p style="font-family: arial; color: #333; font-size: 16px;">Dear User</p>
                <p style="font-family: arial; color: #333; font-size: 16px;">Your password has been successfully reset!</p>
                <p style="font-family: arial; color: #333; font-size: 16px;">Your new password is {{ $newPassword }}</p>
                <p style="font-family: arial; color: #333; font-size: 16px;">Thanks</p>
                <p style="font-family: arial; color: #333; font-size: 16px;">Team Lucky Draw</p>
                </td>
            </tr>
        </table>
    </body>
</html>
